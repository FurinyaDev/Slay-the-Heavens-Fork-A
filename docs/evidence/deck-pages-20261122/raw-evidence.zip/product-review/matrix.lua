local build=assert(os.getenv('DECK_REVIEW_BUILD'))
package.path=build..'/?.lua;src/lua/?.lua;tests/lua/?.lua;'..package.path
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Deck=require('abyss_deck_ui')
local Data,Combat=F.Data,F.Combat
local panelSpec
local function find(nodes)
 for _,node in ipairs(nodes) do if node.name=='deckPanel' then return node end
  local child=find(node.children or {});if child then return child end
 end
end
panelSpec=assert(find(F.Layout))
local panel=F.control(panelSpec)
local native,created,destroyed={},0,0
local function allocate(name,parent)
 assert(name=='AbyssBattlePileCard')
 created=created+1
 local child=F.control(assert(F.Templates[name]),parent)
 parent.children['browser_cell_'..created]=child;native[child]=created
 return child
end
local platform={imageSource='static',color=function(r,g,b,a)return{r=r,g=g,b=b,a=a}end,
 deckBrowser={create=function(parent)return allocate('AbyssBattlePileCard',parent)end,
  destroy=function(cell)
   assert(native[cell]);cell.parent.children['browser_cell_'..native[cell]]=nil
   destroyed=destroyed+1;native[cell]=nil
  end,
  budget=.050}}
local deck
deck=Deck.new(panel,F.Presentation,'click',platform,function()return deck:close()end)
local function update()
 for i=1,25 do deck:update(1/60);if not deck.pendingGrid then
  assert(not deck.prepareError,deck.prepareError);return
 end end
 error('browser never ready')
end
local function course(n)
 local ids={'strike','defend','bash','rampage','inflame','barricade','burn','regret','dazed','wound'}
 local cards={}
 for i=1,n do cards[i]={uid=i,cardId=ids[(i-1)%#ids+1],upgraded=i%3==0} end
 return cards
end
local run={deck={},data=Data,phase='map',relics={},rng={seed=21409}}
local host=panel:GetChild('pileGrid')
local grid=panel:GetChild('grid');grid.destroyOnRefresh=true
local function visible()
 local count=0
 for _,entry in pairs(host.children) do
  if entry.visible and entry:GetChild('hit').raycastTarget then count=count+1
  else assert(not entry:GetChild('hit').raycastTarget,'hidden slot still accepts input') end
 end
 return count
end
local next=panel:GetChild('next'):GetChild('hit')
local previous=panel:GetChild('previous'):GetChild('hit')
local pageHint=panel:GetChild('pageHint')
for _,n in ipairs({0,1,7,10,11,20,75,250}) do
 run.deck=course(n)
 assert(deck:open(run));update()
 assert(visible()==math.min(10,n),'wrong initial visible count '..n)
 assert(deck.pageCount==math.ceil(n/10) and deck.pageIndex==1)
 assert(pageHint.text:find(n..' 张',1,true))
 assert(not previous.interactable and next.interactable==(n>10))
 local visited=visible()
 for page=2,deck.pageCount do
  assert(next.click());update()
  assert(deck.pageIndex==page)
  visited=visited+visible()
 end
 assert(visited==n,'lost instances across pages')
 local final=deck.pageIndex
 assert(not next.click() and not next.interactable)
 assert(deck:close() and visible()==0)
 assert(deck:open(run));update()
 assert(deck.pageIndex==final,'same-entry reopen lost valid position')
 assert(deck:setSort('type') and deck.pageIndex==1);update()
 assert(deck:close() and visible()==0)
 print('PASS matrix n='..n..' total='..visited..' nativeCreated='..created..' nativeDestroyed='..destroyed)
end
assert(created==10 and destroyed==0,'browser exceeded ten physical faces')
run.deck=course(75);assert(deck:open(run));update()
for i=1,7 do assert(next.click());update() end
assert(deck.pageIndex==8 and deck:close())
run.deck=course(7);assert(deck:open(run));update()
assert(deck.pageIndex==1 and deck.pageCount==1 and visible()==7 and deck:close())
print('PASS same-entry position clamps on shrink')
run.phase='combat'
run.combat=Combat.new(Data,{deck={'bash','defend'},enemies={'cultist'}})
run.combat.phase='player'
run.combat.discard={{uid=203,cardId='rampage',costForTurn=0,damageBonus=17}}
assert(deck:openPile(run,'discard'));update()
for _,entry in ipairs(host:GetChildren()) do if entry.visible then
 local face=entry:GetChild('face')
 assert(face:GetChild('cost').text=='0','current temporary cost missing')
 assert(face:GetChild('label').text:find('25',1,true),'current damage growth missing')
 assert(entry:GetChild('hit').click())
end end
assert(deck.cardDetail.instance.uid==203 and deck.cardDetail.combat)
assert(deck:back());update();assert(deck:close())
local card=run.combat.hand[1]
local picked={}
local function onPick(token,uid)picked[#picked+1]={token,uid};return true end
local choice={token='required',op='upgradeHand',cards={card}}
run.combat.pendingChoice=choice
assert(deck:open(run,choice,onPick));deck:update(0)
assert(not deck.paged and not host.visible and grid.visible and not next.parent.visible)
assert(not deck:back(),'required selection dismissed')
assert(grid.items[0]:GetChild('hit').click()==nil and not deck.visible)
assert(picked[1][1]=='required' and picked[1][2]==card.uid)
choice={token='optional',op='codex',optional=true,cards={card}}
run.combat.pendingChoice=choice
assert(deck:open(run,choice,onPick));deck:update(0)
assert(deck:back() and not deck.visible and picked[2][1]=='optional' and picked[2][2]==0)
choice={token='multiple',op='exhaustMany',multiple=true,required=1,selected={},cards={card}}
run.combat.pendingChoice=choice
assert(deck:open(run,choice,onPick));deck:update(0)
assert(not deck:back(),'unmet required count confirmed')
choice.selected[1]=card.uid
local close=panel:GetChild('close'):GetChild('hit')
assert(not close.interactable,'required count status changed outside a new generation')
assert(deck:close())
local info={id='fixture',deck={
 {id='strike',definition=F.Presentation.strike and (function()for _,d in ipairs(Data.cards.cards)do if d.id=='strike'then return d end end end)(),
  display=F.Presentation.strike,count=20}
}}
assert(deck:openPreview(info));update()
assert(deck.pageCount==2 and deck.run.readOnlyPreview)
assert(next.click());update();assert(deck.pageIndex==2 and visible()==10)
assert(deck:close() and deck:openPreview(info));update();assert(deck.pageIndex==2)
assert(deck:close())
deck:syncRun({});assert(destroyed==10 and next.host==nil)
print('DECK_REVIEW_MATRIX_PASS')
