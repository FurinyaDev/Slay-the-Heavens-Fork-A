from pathlib import Path
from collections import defaultdict
from math import ceil
from statistics import median
from hashlib import sha256
import json

root=Path(__file__).parent

def q(data):
    values=sorted(float(v) for v in data)
    return {'n':len(values),'p50':median(values),'p95':values[ceil(.95*len(values))-1],'max':values[-1]}

def read(path):
    rows=[]
    atoms=[]
    header=[]
    for line in path.read_text().splitlines():
        session,tag,*data=line.split('\t')
        if tag=='FIELDS':header=data
        if tag=='ROW':rows.append({'session':session,**dict(zip(header,data,strict=True))})
        if tag=='ATOMS':
            sample,op,*work=data
            atoms.append((session,sample,op,[ar.split('=') for ar in work]))
    return rows,atoms

count,raw_count_atoms = read(root/'count.tsv')
timing,raw_time_atoms = read(root/'timing.tsv')
data={}
def group(rows, dimensions, metrics):
    grouped=defaultdict(list)
    for row in rows:
        key='/'.join(row[d] for d in dimensions)
        grouped[key].append(row)
    return {key:{m:q(r[m] for r in selected) for m in metrics} for key,selected in grouped.items()}

data['hostTiming']=group(timing,['target','profile','amount','operation'],
    ['callback_ms','total_ms','max_step_ms','turns'])
data['hostAtomsByRole']={name:q(rows)
    for name,rows in [(name,[t for _,_,op,parts in raw_time_atoms if op=='cold' for label,t in parts if label==name])
        for name in sorted(set(label for _,_,_,parts in raw_time_atoms for label,_ in parts))]}
data['counted']=count
if (root/'observer.tsv').exists():
    rows,_=read(root/'observer.tsv')
    data['observer']=group(rows,['mode','profile','amount','operation'],['total_ms','max_step_ms'])
def hash(path):return sha256(path.read_bytes()).hexdigest()
data['snapshot']={
    'base':(root/'snapshot/base.sha').read_text().strip(),
    'sourceInventorySha256':hash(root/'snapshot/source.digests'),
    'trackedDiffSha256':hash(root/'snapshot/candidate-tracked.diff'),
    'layoutSha256':hash(root/'snapshot/generated/game-ui.json'),
    'templatesSha256':hash(root/'snapshot/generated/game-ui-templates.json'),
    'flagsSha256':hash(root/'snapshot/generated/abyss_art_features.lua'),
    'simulatorWorkerSha256':'de72d4f80b230cfac330ab0ac6fa9d05e51bb8f51d352f08dd1ee6bcba0fe09d',
}
sdk={}
for arm in ('FULL_TEMPLATE','SPLIT_TEMPLATE'):
    records=[json.loads(path.read_text())['records'] for path in sorted(root.glob(f'sdk-atomic-*-{arm}.json'))]
    atom_times=defaultdict(list)
    totals=[]
    tree_hashes=set()
    for tree,sample in records:
        tree_hashes.add(sha256(tree.encode()).hexdigest())
        _,face,parts=sample.split('\t')
        face=list(map(float,face.split(',')))
        parts=list(map(float,parts.split(','))) if parts else []
        parts_count=len(parts)//len(face)
        roles=('Back','Banner','Frame0','Frame1','Frame2')
        atom_times['root'].extend(face)
        for i,whole in enumerate(face):
            attached=parts[i*parts_count:(i+1)*parts_count]
            for name,value in zip(roles,attached):
                atom_times[name].append(value)
            totals.append(whole+sum(attached))
    sdk[arm]={'treeHash':sorted(tree_hashes),'atomRoles':{k:q(v) for k,v in atom_times.items()},
        'allCreateAtoms':q(x for v in atom_times.values() for x in v),
        'above4ms':sum(x>4 for v in atom_times.values() for x in v),
        'createOnlyPerCardCpuOrSdkClock':q(totals)}
data['publicSdk']=sdk
(root/'results.json').write_text(json.dumps(data,indent=2)+'\n')
for key,row in data['hostTiming'].items():
    print(key,row)
print('hostAtomsByRole',data['hostAtomsByRole'])
print('sdk',data['publicSdk'])
