package.path=(os.getenv('LIFECYCLE_GENERATED') or 'build/official')..'/?.lua;build/lua/?.lua;src/lua/?.lua;'..package.path
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Controller=require('abyss_controller')
local Deck=require('abyss_deck_ui')
local Run=require('abyss_run')
local cards={'strike','defend','inflame','demon_form','heavy_blade','burn','doubt'}
local function kind(i) return cards[i % #cards+1] end
local function same(a,b)
    if type(a)~='table' or type(b)~='table' then return a==b end
    for k,v in pairs(a) do if not same(v,b[k]) then return false end end
    for k in pairs(b) do if a[k]==nil then return false end end
    return true
end
local function amount(n,base)
    local set={}
    for i=1,n do set[i]={uid=base+i,cardId=kind(i),upgraded=i%3==0} end
    return set
end
local root=F.Viewport.apply(F.control({children=F.Layout}),1280,720)
local using,focus=false
local manager=Controller.new({events={Confirm='confirm',Cancel='cancel'},directions={},modes={},getFocus=function()return focus end,
    setFocus=function(c)focus=c end,isController=function()return using end})
local panel=root:GetChild('deckPanel');local base=panel:GetChild('pileGrid');local grid=panel:GetChild('grid')
local creates,destroys,chunks=0,0,0
local ui,factory
factory=F.deckBrowser()
local create,destroy=factory.create,factory.destroy
function factory.create(parent,part)
    if part then chunks=chunks+1 else creates=creates+1 end
    return create(parent,part)
end
function factory.destroy(box)
    destroys=destroys+1
    return destroy(box)
end
local platform={imageSource='static',color=function(...)return {...}end,controller=manager,
    cursorEvents={CursorDown='down',CursorUp='up',CursorExit='exit',CursorEndDrag='end'},controllerApi=manager.api,
    deckBrowser=factory}
ui=Deck.new(panel,F.Presentation,'click',platform,function()return ui:close()end)
local function settle()
    for _=1,40 do
        ui:update(.016);manager:tick();manager:sync('deck')
        if not ui.pendingGrid then assert(not ui.prepareError,ui.prepareError);return end
    end
    error('not ready')
end
local function observe(box)
    local counts={objects=0,cursor=0,nav=0,slots=0,visible=0}
    local function visit(c)
        counts.objects=counts.objects+1
        for _ in pairs(c.listeners or {}) do counts.cursor=counts.cursor+1 end
        for _ in pairs(c.navigationListeners or {}) do counts.nav=counts.nav+1 end
        for _,child in pairs(c.children or {}) do visit(child) end
        for _,child in pairs(c.items or {}) do visit(child) end
    end
    for _,child in pairs(box.children or {}) do
        counts.slots=counts.slots+1;if child.visible then counts.visible=counts.visible+1 end
    end
    visit(box);return counts
end
local function checkPartial(expected)
    local shown=0
    for _,card in pairs(base.children) do
        local hit=card:GetChild('hit')
        if card.visible then assert(hit.raycastTarget);shown=shown+1
        else assert(not hit.raycastTarget and not hit.click({touchId=9000})) end
    end
    assert(shown==expected,'visible '..shown..', expected '..expected)
end
local run=Run.new(F.Data,42)
local chosenSet={0,1,7,10,11,20,75,250}
for _,n in ipairs(chosenSet) do
    local nextRun=Run.new(F.Data,n+99)
    nextRun.deck=amount(n,0)
    local snapshot=F.Combat.copy(nextRun)
    assert(ui:open(nextRun));settle();checkPartial(math.min(n,10))
    assert(ui.pageIndex==1 and ui.pageCount==math.ceil(n/10))
    for j=2,ui.pageCount do assert(ui:controllerStep(1));settle();assert(ui.pageIndex==j) end
    checkPartial(n==0 and 0 or (n-1)%10+1)
    assert(not ui:controllerStep(1))
    assert(ui:close());assert(ui:open(nextRun));settle()
    assert(ui.pageIndex==math.max(ui.pageCount,1));assert(ui:close());assert(same(nextRun,snapshot))
    print('PASS read-only permanent n='..n..' page/empty/boundary/clamp')
end
run.deck=amount(20,900)
assert(Run.startCombat(run,'cultist_solo'))
run.relics[#run.relics+1]='frozen_eye'
run.combat.draw=amount(20,1100);run.combat.discard=amount(20,1200);run.combat.exhaust=amount(20,1300)
run.combat.draw[20].cardId='heavy_blade';run.combat.draw[20].costForTurn=0
local snapshot=F.Combat.copy(run)
assert(ui:openPile(run,'draw'));settle();assert(ui.cards[1].uid==1120 and ui.cards[20].uid==1101)
for _,box in pairs(base.children) do
    if box.x==-354 and box.y>0 then
        local face=box:GetChild('face')
        print('Frozen Eye draw top uid='..ui.cards[1].uid..' cost='..face:GetChild('cost').text..' halo='..tostring(face:GetChild('costHalo').visible))
        assert(face:GetChild('cost').text=='0')
    end
end
assert(ui:controllerStep(1));settle();using=true;settle();assert(ui.pageIndex==2);using=false;settle();assert(ui.pageIndex==2)
assert(ui:close());settle();assert(ui:openPile(run,'draw'));settle();assert(ui.pageIndex==2);assert(ui:close())
assert(ui:openPile(run,'exhaust'));settle();assert(ui.pageIndex==1);assert(ui:setPileSort('cost'));settle();assert(ui:close())
assert(ui:openPile(run,'discard'));settle();assert(ui.cards[1].uid==1201 and ui.cards[20].uid==1220);assert(ui:close())
assert(same(run,snapshot))
local before,oldCreate,oldDestroy,oldRecords,oldChunks=observe(panel),creates,destroys,#manager.records,chunks
for i=1,20 do
    for _,pile in ipairs({'draw','discard','exhaust'}) do
        assert(ui:openPile(run,pile));settle();assert(ui:controllerStep(1));settle();assert(ui:setPileSort('type'));settle();assert(ui.pageIndex==1);assert(ui:close());settle()
    end
    assert(ui:open(run));settle();assert(ui:controllerStep(1));settle();assert(ui:close());settle()
    assert(same(observe(panel),before) and oldCreate==creates and oldDestroy==destroys and oldRecords==#manager.records and oldChunks==chunks)
end
local after=observe(panel);local browsed=observe(base);local hiddenGrid=observe(grid)
print('PASS 20 mixed-power loops x4 entry points panels='..after.objects..' roots='..browsed.slots..' pool objects='..browsed.objects..' hiddenGrid='..hiddenGrid.objects..' records='..#manager.records..' panel cursor='..after.cursor..' nav='..after.nav..' new root/destroy='..(creates-oldCreate)..'/'..(destroys-oldDestroy)..' chunk delta='..(chunks-oldChunks))
local newRun=Run.new(F.Data,11);ui:syncRun(newRun);assert(observe(base).slots==0 and #manager.records==oldRecords-10)
assert(same(run,snapshot))
print('PASS Run replacement releases all 10 roots + 10 controller records')
