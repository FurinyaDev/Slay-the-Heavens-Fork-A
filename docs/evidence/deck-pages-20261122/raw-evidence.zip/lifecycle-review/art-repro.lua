package.path=(os.getenv('LIFECYCLE_GENERATED') or 'build/official')..'/?.lua;build/lua/?.lua;src/lua/?.lua;'..package.path
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Art=require('abyss_card_art_runtime')
local Run=require('abyss_run')
local Deck=require('abyss_deck_ui')
local Native=dofile('tests/lua/support/native_art_controls.lua')
local data={runtime=true,cardId='strike',slots={{image=100001,imageType='stretch',size={1,1},position={0,0},anchorMin={.5,.5},anchorMax={.5,.5},pivot={.5,.5},scale={1,1},rotation={0,0,0},colour={255,255,255,255}}}}
local run=Run.new(F.Data,42);run.deck={}
for i=1,12 do run.deck[i]={uid=i,cardId='strike'} end
local presentation=F.Combat.copy(F.Presentation);presentation.strike.nativeArt=data
local root=F.Viewport.apply(F.control({children=F.Layout}),1280,720)
local factory=F.deckBrowser()
local create=factory.create
function factory.create(parent,part)
    local box=create(parent,part)
    if not part then
        local face=box:GetChild('face')
        if not face:GetChild('artSamples') then face.children.artSamples=F.control({name='artSamples',kind='container',size={144,64}},face) end
    end
    return box
end
local platform={imageSource='static',color=function(...)return {...}end,presentationPage=Art.setPresentationPage,deckBrowser=factory}
local panel=root:GetChild('deckPanel');local deck=Deck.new(panel,presentation,'click',platform,function()return true end)
local fakeNative={__index=function()return function()return true end end}
Art.configure({imageTemplateIndex=1,containerTemplateIndex=2,instantiate=function()return setmetatable({alive=true},fakeNative)end,destroy=function(c)c.alive=false end})
local function advance()for _=1,10 do deck:update(.016);Art.update() end end
local function artStatus(tag)
    local stats=Art.status();local ready,reason=Art.presentationReady('deckPanel')
    print(tag..' ready='..tostring(ready)..' reason='..tostring(reason)..' allocated='..stats.livePools..' waiting='..stats.waitingPools..' controls='..stats.liveControls)
    return stats,ready
end
assert(deck:open(run));advance();local stats,ready=artStatus('page1');assert(ready and stats.livePools==10)
assert(deck:controllerStep(1));advance();stats,ready=artStatus('page2');assert(ready and stats.livePools==2)
assert(deck:close());advance();stats,ready=artStatus('close');assert(ready and stats.livePools==0)
Art.setPresentationPage('battlePanel')
local old={}
for i=1,10 do
    old[i]=F.control({kind='container'});local p=F.control({kind='container'});local f=F.control({kind='image'})
    Art.request(old[i],p,data,platform,f,i,function()end)
end
advance();assert(Art.status().livePools==10)
assert(deck:open(run));advance();stats,ready=artStatus('old battle leases + current page2')
assert(ready,'old battle owners permanently block current browser requests')
