package.path=(os.getenv('LIFECYCLE_GENERATED') or 'build/formal')..'/?.lua;build/lua/?.lua;src/lua/?.lua;'..package.path
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Gate=require('abyss_page_reveal')
local Run=require('abyss_run')
local cursor={CursorDown='down',CursorUp='up',CursorExit='exit',CursorEndDrag='end'}
local function roster(size)
    local ids={'demon_form','bash','defend','burn','heavy_blade','inflame','strike'}
    local cards={}
    for i=1,size do cards[i]={uid=1000+i,cardId=ids[(i-1)%#ids+1],upgraded=i%3==0} end
    return cards
end
local function setup()
    local factory=F.deckBrowser()
    assert(#factory.parts==5,'this suite requires the formal shell+five segments')
    local host,focus
    local api={events={Confirm='confirm',Cancel='cancel',Focus='focus'},directions={Left='left',Right='right'},modes={Specified='specified'},
        getFocus=function()return focus end,setFocus=function(c)focus=c end,isController=function()return true end}
    local root=F.Viewport.apply(F.control({children=F.Layout}),1280,720)
    local panel=root:GetChild('deckPanel')
    local container=panel:GetChild('pileGrid')
    local s={root=root,container=container,creates=0,chunks=0,destroys=0,peak=0,allocated={},engineDestroy=factory.destroy}
    local create,destroy=factory.create,factory.destroy
    function factory.create(parent,part)
        assert(parent.alive,'attempted native instantiate under dead parent')
        if s.before then local accepted=s.before(part);if accepted==false then return nil end end
        local made=create(parent,part)
        if part then s.chunks=s.chunks+1 else s.creates=s.creates+1 end
        s.allocated[#s.allocated+1]=made
        s.peak=math.max(s.peak,#container:GetChildren())
        assert(s.peak<=10)
        if s.after then s.after(made,part) end
        return made
    end
    function factory.destroy(control)
        assert(control.alive and control.parent and control.parent.alive,'illegal Lua destroy of retired native object')
        s.destroys=s.destroys+1
        return destroy(control)
    end
    host=F.GameUI.new(root,F.Data,F.Presentation,'click',{seed=1,imageSource='static',cursorEvents=cursor,controllerApi=api,
        deckBrowser=factory,color=function(r,g,b,a)return {r=r,g=g,b=b,a=a}end,
        presentationReady=function(intent)
            if host and intent.page=='deckPanel' then
                local deck=host.deckUI
                if deck.prepareError then return false,deck.prepareError end
                return not (deck.pending or deck.pendingGrid or deck.calibrating)
            end
            return true
        end})
    s.host,s.deck,s.factory=host,host.deckUI,factory
    local function tick()
        host:update(.016)
        if host.disabled then return end
        local changed,repaint=host.pageReveal:step(Gate.intent(host),.016)
        if changed then if repaint==false then host:syncController() else host:refresh() end end
        host.pageReveal:paint(true)
    end
    local function waitFor(condition)
        for _=1,100 do if condition() then return end;tick() end
        error('condition never met, page state='..host.pageReveal.state..'; error='..tostring(host.pageReveal.error))
    end
    local function settle()waitFor(function()return not host.pageReveal:covered()end)end
    settle();assert(host:start());settle();assert(F.confirmStart(host));settle()
    assert(host.mode=='map')
    host.run.deck=roster(20)
    s.settle,s.waitFor,s.tick=settle,waitFor,tick
    return s
end
local function verifyFull(s)
    assert(#s.container:GetChildren()==10)
    assert(not s.deck.pendingGrid and not s.deck.prepareError)
    for _,card in ipairs(s.container:GetChildren()) do
        for _,part in ipairs(s.factory.parts) do
            local mount=card
            for _,name in ipairs(part.path) do mount=assert(mount:GetChild(name)) end
            local chunks=mount:GetChildren()
            assert(#chunks==1 and chunks[1].name==part.name and chunks[1].alive,'missing or duplicate native segment')
        end
    end
end
local function rejectPart(i)
    local s=setup()
    local target=s.factory.parts[i]
    s.before=function(part)
        if part==target then s.before=nil;return false end
    end
    assert(s.host:openDeck())
    s.waitFor(function()return s.host.pageReveal.state=='failed'end)
    assert(s.deck.prepareError and #s.container:GetChildren()<=1 and s.chunks==i-1)
    assert(s.host:recoverPage());s.settle();assert(s.host:openDeck());s.settle()
    verifyFull(s)
    assert(s.creates-s.destroys==10 and s.peak==10)
    print('PASS reject then retry segment '..i..' shell/part/destroy='..s.creates..'/'..s.chunks..'/'..s.destroys)
end
local function closeDuring(partSelector)
    local s=setup()
    s.after=function(_,part)
        if partSelector(part) then s.after=nil;assert(s.host:closeDeck()) end
    end
    assert(s.host:openDeck());s.settle();assert(not s.deck.visible)
    for _,card in ipairs(s.container:GetChildren())do assert(not card.visible and not card:GetChild('hit').raycastTarget)end
    assert(s.host:openDeck());s.settle();verifyFull(s)
    assert(s.chunks==50 and s.peak==10)
    print('PASS close inside Instantiate shell/part/destroy='..s.creates..'/'..s.chunks..'/'..s.destroys)
end
local function fastReopenDuring(partSelector)
    local s=setup()
    local touched
    s.after=function(made,part)
        if partSelector(part) then
            s.after=nil;touched=made;assert(s.host:closeDeck());assert(s.host:openDeck())
        end
    end
    assert(s.host:openDeck());s.settle();verifyFull(s)
    assert(touched and s.creates-s.destroys==10 and s.peak==10)
    print('PASS close and same-turn reopen inside Instantiate shell/part/destroy='..s.creates..'/'..s.chunks..'/'..s.destroys)
end
local function swapDuring(partSelector)
    local s=setup()
    local oldRun=s.host.run
    local replacement=Run.new(F.Data,891);replacement.deck=roster(20)
    local stale
    s.after=function(made,part)
        if partSelector(part) then s.after=nil;stale=made;s.host.run=replacement;s.host:refresh() end
    end
    assert(s.host:openDeck());s.settle()
    assert(s.host.run~=oldRun and s.host.run==replacement and not s.deck.visible and #s.container:GetChildren()==0)
    assert(stale.alive==false and s.destroys==1)
    for _,made in ipairs(s.allocated)do assert(made.alive==false,'old Run native descendant survived')end
    assert(s.host:openDeck());s.settle();verifyFull(s);assert(s.deck.pageIndex==1)
    print('PASS Run swap inside Instantiate old handles all dead, replacement shells=10 peak='..s.peak)
end
local function destroyDuring(partSelector)
    local s=setup()
    local oldListeners={}
    s.after=function(made,part)
        if partSelector(part) then
            s.after=nil
            for _,card in ipairs(s.container:GetChildren())do
                local hit=card:GetChild('hit')
                if hit.click then oldListeners[#oldListeners+1]=hit.click end
            end
            s.host:onEngineDestroy()
            for _,card in ipairs(s.container:GetChildren()) do s.engineDestroy(card) end
            assert(not made.alive)
        end
    end
    assert(s.host:openDeck());s.waitFor(function()return s.host.disabled end)
    assert(s.destroys==0 and #s.container:GetChildren()==0 and not s.host:update(.016))
    for _,click in ipairs(oldListeners)do assert(not click({touchId=99}))end
    for _,record in ipairs(s.host.controller.records)do assert(record.control.alive~=false,'controller retained destroyed browser binding')end
    print('PASS OnDestroy inside Instantiate no Lua full root destroys and no stale callbacks')
end
local function throwsAfterCreatingShell()
    local s=setup()
    s.after=function(_,part)
        if not part then s.after=nil;error('test: native allocated a shell before returning a handle')end
    end
    assert(s.host:openDeck());s.waitFor(function()return s.host.pageReveal.state=='failed'end)
    assert(s.deck.prepareError and s.creates==1)
    assert(s.host:recoverPage());s.settle();assert(s.host:openDeck())
    s.waitFor(function()return not s.host.pageReveal:covered() or s.host.pageReveal.state=='failed'end)
    assert(not s.deck.prepareError,'partial shell remained and exceeded ten: peak='..s.peak..', error='..tostring(s.deck.prepareError))
    verifyFull(s)
    print('PASS failure after a side-effecting shell allocation does not exceed ten roots')
end
local function throwsAfterCreatingSegment()
    local s=setup()
    s.after=function(_,part)
        if part==s.factory.parts[2] then s.after=nil;error('test: native allocated a part before wrapper raised')end
    end
    assert(s.host:openDeck())
    s.waitFor(function()return s.host.pageReveal.state=='failed'end)
    assert(s.deck.prepareError and s.chunks==2)
    assert(s.host:recoverPage());s.settle();assert(s.host:openDeck());s.settle()
    verifyFull(s)
    print('PASS failure after side-effecting segment allocation does not retain duplicate')
end
local scenarios={}
for i=1,5 do scenarios[#scenarios+1]={'reject segment '..i,function()rejectPart(i)end}end
scenarios[#scenarios+1]={'close during shell',function()closeDuring(function(part)return not part end)end}
scenarios[#scenarios+1]={'close during segment',function()closeDuring(function(part)return part~=nil end)end}
scenarios[#scenarios+1]={'fast reopen during shell',function()fastReopenDuring(function(part)return not part end)end}
scenarios[#scenarios+1]={'fast reopen during segment',function()fastReopenDuring(function(part)return part~=nil end)end}
scenarios[#scenarios+1]={'swap during shell',function()swapDuring(function(part)return not part end)end}
scenarios[#scenarios+1]={'swap during segment',function()swapDuring(function(part)return part~=nil end)end}
scenarios[#scenarios+1]={'destroy during shell',function()destroyDuring(function(part)return not part end)end}
scenarios[#scenarios+1]={'destroy during segment',function()destroyDuring(function(part)return part~=nil end)end}
scenarios[#scenarios+1]={'chunk side effect followed by throw',throwsAfterCreatingSegment}
scenarios[#scenarios+1]={'shell side effect followed by throw',throwsAfterCreatingShell}
local failures=0
for _,case in ipairs(scenarios)do
    local ok,reason=pcall(case[2])
    if not ok then print('FAIL '..case[1]..': '..tostring(reason));failures=failures+1 end
end
assert(failures==0,failures..' scenarios failed')
