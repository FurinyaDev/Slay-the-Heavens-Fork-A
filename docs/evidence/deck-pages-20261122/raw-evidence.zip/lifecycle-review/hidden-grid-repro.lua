package.path=(os.getenv('LIFECYCLE_GENERATED') or 'build/official')..'/?.lua;build/lua/?.lua;src/lua/?.lua;'..package.path
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Controller=require('abyss_controller')
local Deck=require('abyss_deck_ui')
local Run=require('abyss_run')
local cards={'strike','defend','inflame','demon_form','heavy_blade','burn','doubt'}
local function kind(i) return cards[i % #cards+1] end
local function same(a,b)
    if type(a)~='table' or type(b)~='table' then return a==b end
    for k,v in pairs(a) do if not same(v,b[k]) then return false end end
    for k in pairs(b) do if a[k]==nil then return false end end
    return true
end
local function amount(n,base)
    local set={}
    for i=1,n do set[i]={uid=base+i,cardId=kind(i),upgraded=i%3==0} end
    return set
end
local root=F.Viewport.apply(F.control({children=F.Layout}),1280,720)
local using,focus=false
local manager=Controller.new({events={Confirm='confirm',Cancel='cancel'},directions={},modes={},getFocus=function()return focus end,
    setFocus=function(c)focus=c end,isController=function()return using end})
local panel=root:GetChild('deckPanel');local base=panel:GetChild('pileGrid');local grid=panel:GetChild('grid')
local creates,destroys,chunks=0,0,0
local ui,factory
factory=F.deckBrowser()
local create,destroy=factory.create,factory.destroy
function factory.create(parent,part)
    if part then chunks=chunks+1 else creates=creates+1 end
    return create(parent,part)
end
function factory.destroy(box)
    destroys=destroys+1
    return destroy(box)
end
local platform={imageSource='static',color=function(...)return {...}end,controller=manager,
    cursorEvents={CursorDown='down',CursorUp='up',CursorExit='exit',CursorEndDrag='end'},controllerApi=manager.api,
    deckBrowser=factory}
ui=Deck.new(panel,F.Presentation,'click',platform,function()return ui:close()end)
local function settle()
    for _=1,40 do
        ui:update(.016);manager:tick();manager:sync('deck')
        if not ui.pendingGrid then assert(not ui.prepareError,ui.prepareError);return end
    end
    error('not ready')
end
local function observe(box)
    local counts={objects=0,cursor=0,nav=0,slots=0,visible=0}
    local function visit(c)
        counts.objects=counts.objects+1
        for _ in pairs(c.listeners or {}) do counts.cursor=counts.cursor+1 end
        for _ in pairs(c.navigationListeners or {}) do counts.nav=counts.nav+1 end
        for _,child in pairs(c.children or {}) do visit(child) end
        for _,child in pairs(c.items or {}) do visit(child) end
    end
    for _,child in pairs(box.children or {}) do
        counts.slots=counts.slots+1;if child.visible then counts.visible=counts.visible+1 end
    end
    visit(box);return counts
end
local function checkPartial(expected)
    local shown=0
    for _,card in pairs(base.children) do
        local hit=card:GetChild('hit')
        if card.visible then assert(hit.raycastTarget);shown=shown+1
        else assert(not hit.raycastTarget and not hit.click({touchId=9000})) end
    end
    assert(shown==expected,'visible '..shown..', expected '..expected)
end

local run=Run.new(F.Data,42);run.deck=amount(20,900);assert(Run.startCombat(run,'cultist_solo'))
local choice={token=1,op='discover',cards=amount(12,2400)}
run.combat.pendingChoice=choice
if os.getenv('DESTROY_GRID')=='1' then grid.destroyOnRefresh=true end
local initial=observe(panel)
assert(ui:open(run,choice,function() return true end));ui:update(.016);settle();assert(not ui.paged)
print('real choice phase records='..#manager.records..' grid objects='..observe(grid).objects)
assert(ui:close());run.combat.pendingChoice=nil
print('warm hidden choice Grid retained objects='..observe(grid).objects..' visible='..tostring(grid.visible)..' records='..#manager.records)
assert(ui:open(run));settle();assert(ui:close())
print('after choice then retained 10 browser faces: total='..observe(panel).objects..' initial='..initial.objects..' choiceGrid='..observe(grid).objects..' browserPool='..observe(base).objects..' records='..#manager.records)
