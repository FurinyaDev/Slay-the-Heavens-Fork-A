package.path=(os.getenv('LIFECYCLE_GENERATED') or 'build/official')..'/?.lua;build/lua/?.lua;src/lua/?.lua;'..package.path
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Gate=require('abyss_page_reveal')
local host,focus
local cursor={CursorDown='down',CursorUp='up',CursorExit='exit',CursorEndDrag='end'}
local api={events={Confirm='confirm',Cancel='cancel',Focus='focus'},directions={Left='left',Right='right'},modes={Specified='specified'},
    getFocus=function()return focus end,setFocus=function(c)focus=c end,isController=function()return true end}
local root=F.Viewport.apply(F.control({children=F.Layout}),1280,720)
local creates,destroys,fail=0,0,false
local factory=F.deckBrowser()
local nativeCreate,nativeDestroy=factory.create,factory.destroy
function factory.create(parent,part)
    if fail then fail=false;return nil end
    if not part then creates=creates+1 end
    return nativeCreate(parent,part)
end
function factory.destroy(box)
    destroys=destroys+1
    return nativeDestroy(box)
end
host=F.GameUI.new(root,F.Data,F.Presentation,'click',{cursorEvents=cursor,controllerApi=api,imageSource='static',
    seed=1,color=function(r,g,b,a)return {r=r,g=g,b=b,a=a}end,presentationReady=function(intent)
        if host and intent.page=='deckPanel' then
            if host.deckUI.prepareError then return false,host.deckUI.prepareError end
            return not (host.deckUI.pending or host.deckUI.calibrating or host.deckUI.pendingGrid)
        end
        return true
    end,
    deckBrowser=factory})
assert(host.deckUI and F.Theme.presentationProfile=='official-assets-first')
local function tick()
    host:update(.016)
    local changed,paint=host.pageReveal:step(Gate.intent(host),.016)
    if changed then if paint==false then host:syncController() else host:refresh() end end
    host.pageReveal:paint(true)
end
local function settle()
    for _=1,100 do tick();if not host.pageReveal:covered() then return end end
    error('not ready: '..tostring(host.pageReveal.state)..' / '..tostring(host.pageReveal.error))
end
settle();assert(host:start());settle();assert(F.confirmStart(host));settle();assert(host.mode=='map')
local deck=host.deckUI
local panel=root:GetChild('deckPanel')
local browser=panel:GetChild('pileGrid')
local returnHit=panel:GetChild('pileReturn'):GetChild('hit')
local nextHit=panel:GetChild('next'):GetChild('hit')
host.run.deck={}
for i=1,20 do host.run.deck[i]={uid=i,cardId=i%2==0 and 'strike' or 'defend'} end
assert(host:openDeck())
assert(deck.pendingGrid and host.pageReveal:covered() and host.pageReveal.localFrame)

local blocker=root:GetChild('pageReveal'):GetChild('blocker')
assert(host.controller.scope=='deck' and not host.controller.blocked() and returnHit.canControllerFocus)
assert(blocker.sizeDeltaX==host.pageReveal.localFrame[3] and blocker.sizeDeltaY==host.pageReveal.localFrame[4])
print('cold open: scope='..host.controller.scope..' return canFocus='..tostring(returnHit.canControllerFocus)..' blocker='..blocker.sizeDeltaX..'x'..blocker.sizeDeltaY)
focus=returnHit;assert(returnHit.navigationListeners.cancel() and not deck.visible)
settle();assert(host:openDeck());assert(deck.pendingGrid)
returnHit.listeners.down({touchId=1});returnHit.listeners.up({touchId=1})
assert(returnHit.click({touchId=1}) and not deck.visible)
settle();assert(host:openDeck());settle()
print('PASS cold pending controller Cancel and touch Return both close with no blocked hit scope')
assert(creates==10)
local hit5
for _,card in ipairs(browser:GetChildren())do if card.x==354 and card.y>0 then hit5=card:GetChild('hit');break end end
assert(hit5)
focus=hit5;host:syncController();local detailConfirm=hit5.navigationListeners.confirm;assert(detailConfirm())
assert(deck.detailPages)
settle();assert(deck:back());settle()
print('detail return: requested slot=5 actual_hit_same='..tostring(focus==hit5)..' actual_is_return='..tostring(focus==returnHit))
assert(focus==hit5)
if os.getenv('TEST_DETAIL_CONFIRM')=='1' then
    assert(not detailConfirm({pressId=1}),'deferred old Confirm can reopen details after restored focus')
    assert(hit5.navigationListeners.confirm({pressId=2}) and deck.detailPages, 'fresh Confirm did not open restored card')
    settle();assert(deck:back());settle()
    print('PASS old Confirm denied after focus restoration; fresh Confirm still opens details')
end
assert(host:closeDeck()); settle()
-- Real pool and native reveal error path. Replace the Run to release warm roots.
local newRun=require('abyss_run').new(F.Data,99)
host.run=newRun;host:refresh();settle();fail=true;assert(host:openDeck());tick();tick()
assert(deck.prepareError and host.pageReveal.state=='failed')
local retry=host:recoverPage()
print('failure recover: result='..tostring(retry)..' deck_open='..tostring(deck.visible)..' exit_open='..tostring(host.exitOpen)..' pending='..tostring(deck.pendingGrid)..' error='..tostring(deck.prepareError))

assert(retry and not deck.visible);settle()
assert(host:openDeck());settle();assert(deck.visible and not deck.pendingGrid and not deck.prepareError)
print('PASS failure closes to recover and reopen retries without retaining failed request')
