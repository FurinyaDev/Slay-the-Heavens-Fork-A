import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync,spawnSync} from 'node:child_process';
import {sourceEpoch} from '../../tests/helpers/closeout-source-epoch.mjs';
import {releaseMergeCiPacket,assertReleaseMergeCurrent} from '../../tests/helpers/release-bootstrap-merge-ci-source.mjs';
const git=(...args)=>execFileSync('git',args,{encoding:'utf8',maxBuffer:32*1024*1024}).trim();
const head=git('rev-parse','HEAD'),base='6c45778c47788c2e69a68d3a48ec7a5a5ba3455b';
const hash=b=>createHash('sha256').update(b).digest('hex');
const blobs=Object.fromEntries(git('ls-tree','-r','--format=%(path)\t%(objectname)',head).split('\n').map(line=>line.split('\t')));
for(const [path,row]of Object.entries(sourceEpoch.proof.current))if(row)assert.equal(blobs[path],row.gitBlob,'exact final committed production blob: '+path);
for(const [path,row]of Object.entries(releaseMergeCiPacket.files))assert.equal(blobs[path],row.current.gitBlob,'exact final committed CI blob: '+path);
assertReleaseMergeCurrent();
const oldArchives=git('diff','--name-only','--diff-filter=M',base,head,'--','*.gz');assert.equal(oldArchives,'','no pre-existing gzip packet changed');
for(const parent of [base,'1cc5479b713edab6fd26db4e20f8eb22b7401cb2'])assert.equal(spawnSync('git',['merge-base','--is-ancestor',parent,head]).status,0);
const packets={};
for(const path of ['tests/helpers/release-pc-split-source.json.gz','tests/helpers/release-pc-split-ci-source.json.gz']){
 const bytes=readFileSync(path),raw=execFileSync('git',['show',head+':'+path],{maxBuffer:32*1024*1024});
 const stored=raw.toString('utf8');
 if(stored.startsWith('version https://git-lfs.github.com/spec/v1')){
  assert(stored.includes('oid sha256:'+hash(bytes)));assert(stored.includes('size '+bytes.length));
 }else assert.equal(hash(raw),hash(bytes));
 packets[path]={sha256:hash(bytes),bytes:bytes.length};
}
const report={head,base,release:'1cc5479b713edab6fd26db4e20f8eb22b7401cb2',product:sourceEpoch.proof.currentCommit,productionBindings:Object.values(sourceEpoch.proof.current).filter(Boolean).length,owners:sourceEpoch.proof.owners.length,ciBindings:Object.keys(releaseMergeCiPacket.files).length,immutableArchives:Object.keys(releaseMergeCiPacket.immutableArchives).length,oldArchivesModified:0,packets,status:git('status','--short')};
writeFileSync('.artifacts/split-ratchet/final-head.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
