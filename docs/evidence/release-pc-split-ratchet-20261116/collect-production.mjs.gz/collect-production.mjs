// Production half of the existing collect-release-pc-source.mjs, with a new
// output path only. The complete original packet is never overwritten.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {preReleasePcSourceEpoch} from '../../tests/helpers/closeout-source-epoch.mjs';
const base='36b9b157ee6f05b65eb9f1da7e2978647d36c210';
const git=(...args)=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024});
const commit=process.argv[2]??git('rev-parse','HEAD').trim(),norm=s=>s.replaceAll('\r\n','\n');
assert.match(commit,/^[a-f0-9]{40}$/);
const hash=b=>createHash('sha256').update(b).digest('hex');
const bind=source=>({source,sha256:hash(source),gitBlob:createHash('sha1').update(`blob ${Buffer.byteLength(source)}\0`).update(source).digest('hex')});
const prior=preReleasePcSourceEpoch.proof;
const paths=['config/architecture.json',...readdirSync('src/lua').filter(p=>p.endsWith('.lua')).map(p=>'src/lua/'+p)].sort();
assert.deepEqual(paths,Object.keys(prior.current).filter(p=>prior.current[p]!==null).sort());
const current={},before={},producers={};
for(const path of paths){
 const old=norm(git('show',base+':'+path)),source=norm(git('show',commit+':'+path));
 assert.equal(norm(readFileSync(path,'utf8')),source,'working production equals exact product commit: '+path);
 assert.deepEqual(bind(old),prior.current[path],'complete canonical release predecessor: '+path);
 if(hash(source)!==prior.current[path].sha256){
  before[path]=prior.current[path];current[path]=bind(source);
  const producer=git('log','-1','--format=%H',commit,'--',path).trim();
  producers[path]={commit:producer,parents:git('show','-s','--format=%P',producer).trim().split(' ').filter(Boolean)};
 }
}
const packet={schemaVersion:1,normalization:'LF',baseCommit:base,currentCommit:commit,currentTreeCommitted:true,before,current,producers};
const bytes=gzipSync(JSON.stringify(packet),{level:9});bytes[9]=10;
writeFileSync('tests/helpers/release-pc-split-source.json.gz',bytes);
console.log(JSON.stringify({commit,sha256:hash(bytes),files:Object.keys(current),producers},null,2));
