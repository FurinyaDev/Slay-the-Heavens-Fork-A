package.path='src/lua/?.lua;build/lua/?.lua;'..package.path
local C,D,R=require('abyss_combat'),require('abyss_data'),require('abyss_sts_random')
local function dump(value)
 if type(value)~='table' then
  assert(type(value)=='string' or type(value)=='number' or type(value)=='boolean' or value==nil,type(value))
  return type(value)..':'..tostring(value)
 end
 local keys,result={},{}
 for key in pairs(value) do keys[#keys+1]=key end
 table.sort(keys,function(a,b)return type(a)..tostring(a)<type(b)..tostring(b)end)
 for _,key in ipairs(keys)do result[#result+1]=dump(key)..'='..dump(value[key]) end
 return '{'..table.concat(result,';')..'}'
end
local cases=0
for _,id in ipairs(PAIR_FAMILY and {PAIR_FAMILY} or {'acid_slime_l','spike_slime_l','slime_boss'})do
 for _,origin in ipairs({false,{x=0,y=0},{x=281,y=-37}})do
  for _,stream in ipairs({false,true})do
   local s=C.new(D,{enemies={id,'sneaky_gremlin'},deck={'strike'},seed=42})
   if stream then s.aiRng=R.fromSeed('42');s.monsterHpRng=R.fromSeed('66')end
   local parent=s.enemies[1];parent.sourcePosition=origin or nil
   C.damage(s,s.player,parent,parent.hp-23,true)
   assert(C.endTurn(s));assert(#s.enemies==4)
   cases=cases+1
   print('CASE '..cases..' '..id..' '..tostring(stream)..' '..dump(s))
  end
 end
end
print('PAIRED_SPLIT_STATES '..cases)
