import {readFileSync,writeFileSync,readdirSync,statSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const source='.artifacts/split-ratchet',out='docs/evidence/release-pc-split-ratchet-20261116';
assert(statSync(out).isDirectory());
const hash=b=>createHash('sha256').update(b).digest('hex');
const scripts=['run.mjs','verify.mjs','paired.lua','collect-production.mjs','collect-ci.mjs','static.mjs','archive.mjs','audit-head.mjs'];
const manifest=[];
for(const name of readdirSync(source).filter(name=>/\.(?:log|json)$/.test(name)||scripts.includes(name)).sort()){
 if(name==='final-head.json')continue;
 const input=readFileSync(source+'/'+name);
 if(name.endsWith('.json')){
  writeFileSync(out+'/'+name,input);manifest.push({file:name,sha256:hash(input),bytes:input.length});
 }else{
  const bytes=gzipSync(input,{level:9});
  writeFileSync(out+'/'+name+'.gz',bytes);manifest.push({file:name+'.gz',sha256:hash(bytes),bytes:bytes.length,sourceSha256:hash(input),sourceBytes:input.length});
 }
}
writeFileSync(out+'/archive-manifest.json',JSON.stringify({schemaVersion:1,scope:'this-session offline narrow slice; no device/Hosted claims',files:manifest},null,2)+'\n');
console.log(JSON.stringify({files:manifest.length,storedBytes:manifest.reduce((sum,row)=>sum+row.bytes,0)},null,2));
