import {mkdirSync,readFileSync,writeFileSync,copyFileSync,existsSync,renameSync,realpathSync,unlinkSync,symlinkSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const out='.artifacts/split-ratchet';
mkdirSync(out,{recursive:true});
mkdirSync('build/tools/luacheck',{recursive:true});
mkdirSync(`${out}/tmp`,{recursive:true});
process.env.TEMP=process.env.TMP=process.cwd()+'/'+out+'/tmp';
if(realpathSync('node_modules')==='F:\\New folder\\node_modules'){
 unlinkSync('node_modules');symlinkSync('F:/New folder/.worktrees/release-pc-closeout-1115/node_modules','node_modules','junction');
}
const phase=process.argv[2];
function run(name,args,expected=0,env={}){
 const result=spawnSync(process.execPath,args,{encoding:'utf8',timeout:120000,maxBuffer:16*1024*1024,env:{...process.env,...env}});
 writeFileSync(`${out}/${phase}-${name}.log`,JSON.stringify({args,status:result.status,error:result.error?.message})+'\n'+result.stdout+result.stderr);
 console.log(`${phase}/${name}: exit ${result.status}`);console.log(result.stdout);console.error(result.stderr);
 assert.equal(result.status,expected,name);
}
if(phase==='build'){
 run('build-data',['scripts/build-lua-data.mjs']);
 run('build-ui',['scripts/build-ui.mjs']);
}
if(phase==='before'){
 if(existsSync(`${out}/before-ratchet.log`))renameSync(`${out}/before-ratchet.log`,`${out}/infra-temp-ratchet.log`);
 run('ratchet',['scripts/check-quality-ratchet.mjs','--base','1cc5479b713edab6fd26db4e20f8eb22b7401cb2'],1);
 copyFileSync('build/quality-ratchet.json',`${out}/before-ratchet.json`);
 const report=JSON.parse(readFileSync('build/quality-ratchet.json','utf8'));
 assert(report.errors.some(row=>/Module length 2295 -> 2302 exceeds 2295/.test(row.message)));
 assert(report.errors.some(row=>/splitEnemy: CC 14 -> 17 exceeds 15/.test(row.message)));
}
if(phase==='ratchet-green'){
 run('ratchet',['scripts/check-quality-ratchet.mjs','--base','1cc5479b713edab6fd26db4e20f8eb22b7401cb2']);
 copyFileSync('build/quality-ratchet.json',`${out}/after-ratchet.json`);
}
if(phase==='source'){
 if(existsSync(`${out}/source-contracts.log`))renameSync(`${out}/source-contracts.log`,`${out}/source-contracts-prior-${Date.now()}.log`);
 run('contracts',['--test','--test-concurrency=1','tests/release-pc-source.test.mjs','tests/integrated-ci-source.cases.mjs']);
 run('owners',['--test','--test-concurrency=1','--test-name-pattern=current PC 120-owner|frozen pre-PC 116-owner','tests/defect-final-source-epoch.test.mjs','tests/encounter-formation-source-epoch.test.mjs']);
}
if(phase==='copy-bytes')run('contracts',['--test','tests/source-closure-bytes.test.mjs']);
if(phase==='characterize'||phase==='after'){
 run('acid',['scripts/test-lua.mjs','tests/lua/acid_slime_split.lua']);
 run('acid-as-spike',['scripts/test-lua.mjs','tests/lua/acid_slime_split.lua'],0,{SPLIT_FAMILY:'spike'});
 if(phase==='after'){
  for(const [name,file]of [['spike','spike_slime_split'],['boss','act1_bosses'],['acid-ui','acid_slime_split_ui'],['spike-ui','spike_slime_split_ui'],['layout','native_enemy_portraits']])run(name,['scripts/test-lua.mjs',`tests/lua/${file}.lua`]);
 }
}
