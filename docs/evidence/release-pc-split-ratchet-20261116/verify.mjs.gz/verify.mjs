import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,mkdtempSync,readdirSync,existsSync,renameSync} from 'node:fs';
import {spawnSync,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL, fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {copyIntegrationSourceClosure} from '../../tests/helpers/copy-integration-source-closure.mjs';
import {sourceEpoch} from '../../tests/helpers/closeout-source-epoch.mjs';
import {requireLuaTool} from '../../scripts/setup-lua-static.mjs';
import {parseDiagnostics} from '../../scripts/check-lua-static.mjs';
import {measureSources} from '../../scripts/lua-quality-metrics.mjs';
const out='.artifacts/split-ratchet',base='6c45778c47788c2e69a68d3a48ec7a5a5ba3455b';
const hash=b=>createHash('sha256').update(b).digest('hex'),norm=s=>s.replaceAll('\r\n','\n');
const require=createRequire(import.meta.url),cli=require.resolve('fengari-node-cli/src/lua-cli.js');
const old=path=>execFileSync('git',['show',base+':'+path],{encoding:'utf8',maxBuffer:32*1024*1024});
const combat='src/lua/abyss_combat.lua',setup='src/lua/abyss_combat_enemy_setup.lua';
const luaQuote=value=>'[==========['+value+']==========]';
const preload=(name,source)=>`package.preload[ ${luaQuote(name)} ]=assert(load(${luaQuote(source)},${luaQuote(name)}));`;
const currentSetup=readFileSync(setup,'utf8');
function lua(label,script,prefix=''){
 if(existsSync(`${out}/${label}.log`))renameSync(`${out}/${label}.log`,`${out}/${label}-prior-${Date.now()}.log`);
 const wrapper=`${out}/${label}.lua`;writeFileSync(wrapper,prefix+`dofile(${luaQuote(script)})`);
 const result=spawnSync(process.execPath,[cli,'-e',`dofile(${luaQuote(wrapper)})`],{encoding:'utf8',timeout:30000,maxBuffer:64*1024*1024});
 writeFileSync(`${out}/${label}.log`,JSON.stringify({status:result.status,error:result.error?.message,stdoutBytes:Buffer.byteLength(result.stdout),sha256:hash(result.stdout)})+'\n'+(result.status!==0?result.stdout:'')+result.stderr);
 return result;
}
const cohorts=[],outputs=[];
for(const family of ['acid_slime_l','spike_slime_l','slime_boss']){
 const select=`PAIR_FAMILY=${luaQuote(family)};`;
 const before=lua('paired-'+family+'-before',`${out}/paired.lua`,select+preload('abyss_combat',old(combat))+preload('abyss_combat_enemy_setup',old(setup)));
 const after=lua('paired-'+family+'-after',`${out}/paired.lua`,select);
 assert.equal(before.status,0,before.stderr);assert.equal(after.status,0,after.stderr);
 assert.equal(before.stdout,after.stdout,'complete states including catalog, event frames, HP, IDs and all RNG streams');
 assert.match(after.stdout,/PAIRED_SPLIT_STATES 6/);outputs.push(after.stdout);
 cohorts.push({family,cases:6,bytes:Buffer.byteLength(after.stdout),sha256:hash(after.stdout)});
}
const controls={
 offset:currentSetup.replace('childIndex==1 and -134 or 134','childIndex==1 and 0 or 0'),
 floor:currentSetup.replace('y=origin.y','y=0'),
 alias:currentSetup.replace('return Copy(parent.ai.splitPositions[childIndex])','return parent.ai.splitPositions[childIndex]')
};
for(const [name,source]of Object.entries(controls)){
 assert.notEqual(source,currentSetup);
 const result=lua('negative-'+name,'tests/lua/acid_slime_split.lua',preload('abyss_combat_enemy_setup',source));
 assert.notEqual(result.status,0,name);assert.match(result.stdout,/FAIL (split positions|explicit split positions)/,name);
}
const directory=mkdtempSync(resolve(out,'isolated-helper-copy-'));
copyIntegrationSourceClosure(directory);
const copied=await import(pathToFileURL(resolve(directory,'tests/helpers/closeout-source-epoch.mjs')));
assert.deepEqual(copied.sourceEpoch.proof,sourceEpoch.proof,'fresh isolated production helper closure');
const tool=requireLuaTool();
const measured=spawnSync(tool.file,[combat,setup,'--formatter','plain','--codes','--ranges','--no-color','--max-cyclomatic-complexity','0','--only','561'],{encoding:'utf8',timeout:30000,maxBuffer:4*1024*1024});
assert([0,1].includes(measured.status));assert.equal(measured.stderr,'');
const metrics=measureSources(Object.fromEntries([combat,setup].map(path=>[path,norm(readFileSync(path,'utf8'))])),parseDiagnostics(measured.stdout));
assert.deepEqual(metrics.errors,[]);
const selected=metrics.modules.map(row=>({file:row.file,lines:row.lines,functions:row.functions.filter(f=>['splitEnemy','M.splitPosition'].includes(f.name)).map(({name,complexity,line})=>({name,complexity,line}))}));
const output=outputs.join('');
const receipt={base,product:'53e410696bee6209d2ba0152b5548ec46245d1d7',paired:{cases:18,identical:true,cohorts,bytes:Buffer.byteLength(output),sha256:hash(output)},negativeControls:Object.keys(controls),copiedOwners:copied.sourceEpoch.proof.owners.length,isolatedHelperCopy:directory,metrics:selected};
if(existsSync(`${out}/verification.json`))renameSync(`${out}/verification.json`,`${out}/verification-prior-${Date.now()}.json`);
writeFileSync(`${out}/verification.json`,JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));
