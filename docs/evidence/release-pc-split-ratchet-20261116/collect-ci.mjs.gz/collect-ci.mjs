// Append-only adaptation of bootstrap-merged/build-packet.mjs and the existing
// ci-owner-repair-1116/rebind-closeout.mjs. Retain the entire prior packet.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';
const hash=b=>createHash('sha256').update(b).digest('hex');
const binding=source=>({source,sha256:hash(source),gitBlob:createHash('sha1').update(`blob ${Buffer.byteLength(source)}\0`).update(source).digest('hex')});
const oldPath='tests/helpers/release-bootstrap-merge-ci-source.json.gz';
const old=readFileSync(oldPath);assert.equal(hash(old),'533b470c786e02972a0359d6df10b6dbc3d0f946e7e054561f53f9635e77e966');
const packet=JSON.parse(gunzipSync(old));
const show=(commit,path)=>{try{return binding(execFileSync('git',['show',commit+':'+path],{encoding:'utf8',maxBuffer:32*1024*1024}).replaceAll('\r\n','\n'));}catch{return null;}};
const paths=['src/lua/abyss_combat.lua','src/lua/abyss_combat_enemy_setup.lua','tests/lua/acid_slime_split.lua',
 'tests/helpers/closeout-source-epoch.mjs','tests/helpers/release-pc-source.mjs','tests/helpers/release-pc-ci-source.mjs',
 'tests/helpers/copy-integration-source-closure.mjs','tests/release-pc-source.test.mjs','tests/defect-final-source-epoch.test.mjs','tests/encounter-formation-source-epoch.test.mjs'];
for(const path of paths){
 if(!packet.files[path])packet.files[path]={slicePrior:show(packet.slicePriorCommit,path),bootstrapView:show(packet.releaseCommit,path)};
 packet.files[path].current=binding(readFileSync(path,'utf8').replaceAll('\r\n','\n'));
}
packet.immutableArchives[oldPath]=hash(old);
packet.immutableArchives['tests/helpers/release-pc-split-source.json.gz']=hash(readFileSync('tests/helpers/release-pc-split-source.json.gz'));
const bytes=gzipSync(JSON.stringify(packet),{mtime:0});
writeFileSync('tests/helpers/release-pc-split-ci-source.json.gz',bytes);
console.log(JSON.stringify({sha256:hash(bytes),files:Object.keys(packet.files).length,archives:Object.keys(packet.immutableArchives).length,paths},null,2));
