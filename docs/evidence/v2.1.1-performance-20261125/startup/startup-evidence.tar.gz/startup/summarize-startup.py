"""Summarize raw interleaved startup and resource traces."""
import csv
import json
from pathlib import Path
import random
import statistics
import sys
from collections import defaultdict

DIR=Path(__file__).resolve().parent
RAW=DIR/'raw'
OUTPUT=DIR/'results'

MODULE_RANGES={
    'catalogue-source-compile':('module-begin','module-compiled'),
    'catalogue-execute-including-eager-decode':('module-compiled','module-executed'),
    'catalogue-compile-and-execute':('module-begin','module-executed'),
    'first-three-drawings':('module-executed','module-first-access'),
    'repeat-three-drawings':('module-first-access','module-repeat-access'),
    'catalogue-through-first-three':('module-begin','module-first-access'),
}
HOST_RANGES={
    'cold-t1-t2':('cold-t1','cold-t2'),
    'cold-t1-t3':('cold-t1','cold-t3'),
    'cold-t2-t3':('cold-t2','cold-t3'),
    'cold-entry-chunk':('cold-t1','cold-entry-loaded'),
    'selection-and-neow-to-map-tap':('cold-t3','first-fight-begin'),
    'first-fight-gesture-dispatch':('first-fight-begin','first-fight-gesture'),
    'first-fight-gesture-to-operable':('first-fight-begin','first-fight-ready'),
    'cold-through-first-fight':('cold-t1','first-fight-ready'),
    'warm-t1-t2':('warm-t1','warm-t2'),
    'warm-t1-t3':('warm-t1','warm-t3'),
    'warm-t2-t3':('warm-t2','warm-t3'),
}
MEASURE_FIELDS=['wallMs','cpuMs','luaBytes','allocations','frees','requireCalls','moduleLoads','getChild',
    'mapGroupLookups','mapMemberLookups','templateCreates','templateDestroys','controlsCreated','frameCallbacks',
    'observedNativeCalls','observedPropertyWrites']

def read_raw(name):
    file=RAW/(name+'.jsonl')
    return [json.loads(line) for line in file.read_text().splitlines() if line] if file.exists() else []

def stats(values):
    if not values:
        return None
    return {'n':len(values),'min':min(values),'p50':statistics.median(values),'max':max(values)}

def select(rows, variant):
    return [r for r in rows if r['variant']==variant and r['status']=='PASS']

def points(row, label):
    return [phase for phase in row['phases'] if phase['phase']==label]

def point(row,label,index=0):
    return points(row,label)[index]

def span(row, start, end, index=0):
    a,b=point(row,start,index),point(row,end,index)
    return difference(a,b)

def difference(a,b):
    delta={key:b[key]-a[key] for key in MEASURE_FIELDS}
    return {**delta,'luaBytesEnd':b['luaBytes'],'luaPeakBytesEnd':b['luaPeakBytes'],
        'processPeakRSSKiBEnd':b['processPeakRSSKiB']}

def aggregate(rows):
    if not rows:return {}
    return {key:stats([row[key] for row in rows]) for key in rows[0]}

def spans(rows,ranges):
    return {name:aggregate([span(row,*bounds) for row in rows])
        for name,bounds in ranges.items()}

def paired_stats(deltas):
    if not deltas:return {}
    rng=random.Random(954)
    bootstrap=sorted(statistics.median(rng.choices(deltas,k=len(deltas))) for _ in range(2000))
    return {**stats(deltas),'negative':sum(d<0 for d in deltas),'positive':sum(d>0 for d in deltas),
        'medianBootstrap95CI':[bootstrap[50],bootstrap[1949]]}

def compare(rows, before, after, ranges):
    old={r['round']:r for r in select(rows,before)}
    new={r['round']:r for r in select(rows,after)}
    return {label:{metric:paired_stats([
        span(new[r],*bounds)[metric]-span(old[r],*bounds)[metric] for r in sorted(old.keys()&new.keys())
    ]) for metric in ['wallMs','cpuMs','luaBytes','mapGroupLookups','mapMemberLookups','templateCreates','frameCallbacks']}
    for label,bounds in ranges.items()}

def waterfall_ranges(row,run):
    p=lambda label:point(row,label,run)
    start='cold' if run==0 else 'warm'
    sequence=[
        (f'{start}-t1',f'{start}-entry-loaded','Lua entry chunk compile/eval'),
        (f'{start}-entry-loaded','startup-base-modules-begin','OnStart ingress'),
        ('startup-base-modules-begin','startup-base-modules-end','Base modules and gameplay data'),
        ('startup-base-modules-end','startup-gameui-begin','Viewport / visual owners / binding'),
        ('startup-gameui-begin','startup-menu-projection-begin','GameUI constructors and listeners'),
        ('startup-menu-projection-begin','startup-menu-projection-end','First menu Lua projection'),
        ('startup-menu-projection-end','startup-gameui-end','GameUI finalization'),
        ('startup-gameui-end',f'{start}-t2','Resize and enable updates'),
        (f'{start}-t2',f'{start}-t3','Menu page gate and input readiness'),
    ]
    def boundary(label):
        return p(label) if not label.startswith(('cold-','warm-')) else point(row,label)
    values=[]
    for a,b,label in sequence:
        values.append((label,difference(boundary(a),boundary(b))))
    return values

def waterfall(detail,variants):
    result={}
    for variant in variants:
        rows=select(detail,variant)
        result[variant]={}
        for run,name in enumerate(('cold','warm')):
            per_phase=defaultdict(list)
            for row in rows:
                for label,value in waterfall_ranges(row,run):per_phase[label].append(value)
            result[variant][name]=[{ 'stage':name, **aggregate(data)} for name,data in per_phase.items()]
    return result

def function_summary(rows):
    fn=defaultdict(list)
    for row in rows:
        seen=defaultdict(int)
        for item in row['functions']:
            phase,name=item['phase'],item['name']
            if phase=='startup-gameui-begin':
                counters=(phase,name)
                phase+='-cold' if seen[counters]==0 else '-warm'
                seen[counters]+=1
            fn[(phase,name)].append({key:item[key] for key in ['wallMs','cpuMs']})
    return [{'phase':phase,'name':name,**aggregate(data)} for (phase,name),data in fn.items()]

def module_summary(rows):
    grouped=defaultdict(list)
    for row in rows:
        for module in row['modules']:
            key=(module['phase'],module['parent'],module['name'])
            grouped[key].append({k:v for k,v in module.items() if k not in ['phase','parent','name']})
    return sorted(
        ({'phase':phase,'parent':parent,'name':name,**aggregate(data)}
         for (phase,parent,name),data in grouped.items()),
        key=lambda row:row['exclusiveCPUMs']['p50'],reverse=True)

def write_csv(file,rows):
    if not rows:return
    with file.open('w',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def main():
    OUTPUT.mkdir(exist_ok=True)
    module=read_raw('module')
    host=read_raw('host')
    detail=read_raw('detail')
    fengari=read_raw('fengari')
    packaged=read_raw('packaged')
    packaged_detail=read_raw('packaged-detail')
    all_lanes=[('module',module),('host',host),('detail',detail),('fengari',fengari),
        ('packaged',packaged),('packaged-detail',packaged_detail)]
    results={
        'module':{v:{'spans':spans(select(module,v),MODULE_RANGES),'functionTiming':function_summary(select(module,v))}
            for v in sorted({r['variant'] for r in module})},
        'host':{v:spans(select(host,v),HOST_RANGES) for v in sorted({r['variant'] for r in host})},
        'detail':{v:spans(select(detail,v),HOST_RANGES) for v in sorted({r['variant'] for r in detail})},
        'packaged':{v:spans(select(packaged,v),HOST_RANGES) for v in sorted({r['variant'] for r in packaged})},
        'packaged-detail':{v:spans(select(packaged_detail,v),HOST_RANGES) for v in sorted({r['variant'] for r in packaged_detail})},
        'paired':{
            'module-eager-minus-uncompressed':compare(module,'uncompressed','eager',MODULE_RANGES),
            'module-lazy-minus-eager':compare(module,'eager','lazy',MODULE_RANGES),
            'host-eager-minus-uncompressed':compare(host,'rc-uncompressed','rc-eager',HOST_RANGES),
            'host-lazy-minus-eager':compare(host,'rc-eager','rc-lazy',HOST_RANGES),
            'hotfix-minus-rc':compare(host,'rc-lazy','hotfix-lazy',HOST_RANGES),
            'hotfix-minus-live':compare(host,'live-eager','hotfix-lazy',HOST_RANGES),
            'observation-overhead':compare(detail,'rc-lazy','rc-lazy-detailed',HOST_RANGES),
            'detailed-hotfix-minus-rc':compare(detail,'rc-lazy-detailed','hotfix-lazy-detailed',HOST_RANGES),
            'packaged-hotfix-minus-live':compare(packaged,'deployed-live-eager','cd-hotfix-lazy',HOST_RANGES),
        },
        'waterfall':{
            **waterfall(detail,['live-eager-detailed','rc-lazy-detailed','hotfix-lazy-detailed']),
            **waterfall(packaged_detail,['deployed-live-eager-detailed','cd-hotfix-lazy-detailed']),
        },
        'startupFunctions':{v:function_summary(select(detail+packaged_detail,v))
            for v in sorted({r['variant'] for r in detail+packaged_detail if r['detail']})},
        'startupModules':{v:module_summary(select(detail+packaged_detail,v))
            for v in sorted({r['variant'] for r in detail+packaged_detail if r['detail']})},
        'fengariFunctionalCrosscheck':{v:spans(select(fengari,v),HOST_RANGES) for v in sorted({r['variant'] for r in fengari})},
        'outcomes':{lane:{v:{'statusCounts':{status:sum(r['status']==status for r in rows if r['variant']==v)
            for status in sorted({r['status'] for r in rows})},
            'decodedAssets':[json.loads(s) for s in sorted({json.dumps(r['decodedAssets'],sort_keys=True)
                for r in select(rows,v)})],
            'fight':[json.loads(s) for s in sorted({json.dumps(r['fight'],sort_keys=True)
                for r in select(rows,v)})]}
            for v in sorted({r['variant'] for r in rows})}
            for lane,rows in all_lanes},
    }
    (OUTPUT/'startup-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    for name,rows in all_lanes:
        flat=[]
        for row in rows:
            if row['status']!='PASS':continue
            origin=row['phases'][0]
            for phase in row['phases']:
                flat.append({'variant':row['variant'],'round':row['round'],'order':row['order'],
                    **phase,'wallFromFirstMarkMs':phase['wallMs']-origin['wallMs'],
                    'cpuFromFirstMarkMs':phase['cpuMs']-origin['cpuMs']})
        write_csv(OUTPUT/(name+'-phases.csv'),flat)
    wall=[]
    for version,runs in results['waterfall'].items():
        for run,phases in runs.items():
            for p in phases:
                wall.append({'variant':version,'run':run,'phase':p['stage'],
                    'n':p['wallMs']['n'],'wallP50Ms':p['wallMs']['p50'],'wallMaxMs':p['wallMs']['max'],
                    'cpuP50Ms':p['cpuMs']['p50'],'cpuMaxMs':p['cpuMs']['max'],
                    'nativeCallsP50':p['observedNativeCalls']['p50'],
                    'mapGroupLookupsP50':p['mapGroupLookups']['p50']})
    write_csv(OUTPUT/'waterfall.csv',wall)
    for name in ('module','host','detail','packaged','packaged-detail'):
        print(name)
        for variant,info in results[name].items():
            scopes=['catalogue-compile-and-execute','first-three-drawings'] if name=='module' else [
                'cold-t1-t3','warm-t1-t3','first-fight-gesture-to-operable']
            value=info['spans'] if name=='module' else info
            print(variant, ' '.join(f"{scope}={value[scope]['cpuMs']['p50']:.3f}ms CPU/{value[scope]['wallMs']['p50']:.3f}ms wall"
                for scope in scopes))

if __name__=='__main__':
    main()
