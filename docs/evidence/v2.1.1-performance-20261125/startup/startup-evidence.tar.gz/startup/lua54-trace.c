/* Minimal Lua 5.4 CLI bridge for monotonic/process CPU clocks and allocator receipts.
 * The benchmark interpreter is the system stock liblua5.4, not a platform SDK. */
#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <time.h>

typedef struct lua_State lua_State;
typedef int (*lua_CFunction)(lua_State *);
typedef intptr_t lua_KContext;
typedef int (*lua_KFunction)(lua_State *, int, lua_KContext);

extern lua_State *lua_newstate(void *(*alloc)(void *, void *, size_t, size_t), void *);
extern void luaL_openlibs(lua_State *);
extern void lua_pushcclosure(lua_State *, lua_CFunction, int);
extern void lua_setglobal(lua_State *, const char *);
extern int luaL_loadfilex(lua_State *, const char *, const char *);
extern int lua_pcallk(lua_State *, int, int, int, lua_KContext, lua_KFunction);
extern const char *lua_tolstring(lua_State *, int, size_t *);
extern void lua_pushnumber(lua_State *, double);
extern void lua_close(lua_State *);

static size_t lua_bytes, peak_bytes, allocations, frees;
static double time_ms(clockid_t id) {
    struct timespec t;
    clock_gettime(id, &t);
    return (double)t.tv_sec * 1000.0 + (double)t.tv_nsec / 1000000.0;
}
static int clock_values(lua_State *s) {
    lua_pushnumber(s, time_ms(CLOCK_MONOTONIC));
    lua_pushnumber(s, time_ms(CLOCK_PROCESS_CPUTIME_ID));
    return 2;
}
static int memory_values(lua_State *s) {
    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);
    lua_pushnumber(s, (double)lua_bytes);
    lua_pushnumber(s, (double)peak_bytes);
    lua_pushnumber(s, (double)usage.ru_maxrss);
    lua_pushnumber(s, (double)allocations);
    lua_pushnumber(s, (double)frees);
    return 5;
}
static void *track(void *unused, void *ptr, size_t old, size_t size) {
    (void)unused;
    if (size == 0) {
        if (ptr) {
            lua_bytes -= old;
            ++frees;
        }
        free(ptr);
        return NULL;
    }
    int is_new = ptr == NULL;
    void *result = realloc(ptr, size);
    if (result) {
        lua_bytes += size;
        if (is_new) ++allocations;
        else lua_bytes -= old;
        if (lua_bytes > peak_bytes) peak_bytes = lua_bytes;
    }
    return result;
}
static void global(lua_State *s, const char *name, lua_CFunction fn) {
    lua_pushcclosure(s, fn, 0);
    lua_setglobal(s, name);
}
int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s file.lua\n", argv[0]);
        return 2;
    }
    lua_State *s = lua_newstate(track, NULL);
    if (!s) return 2;
    luaL_openlibs(s);
    global(s, "A_CLOCK", clock_values);
    global(s, "A_MEMORY", memory_values);
    int status = luaL_loadfilex(s, argv[1], NULL);
    if (status == 0) status = lua_pcallk(s, 0, 0, 0, 0, NULL);
    if (status) fprintf(stderr, "%s\n", lua_tolstring(s, -1, NULL));
    lua_close(s);
    return status ? 1 : 0;
}
