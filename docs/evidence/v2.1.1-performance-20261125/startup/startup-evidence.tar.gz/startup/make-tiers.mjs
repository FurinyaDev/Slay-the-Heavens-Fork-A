import {readFileSync,writeFileSync} from 'node:fs';
const manifest=JSON.parse(readFileSync(process.argv[2],'utf8'));
const indices={41:4,96:5,115:6};
const variants=Object.entries(manifest.assets).map(([id,value])=>'['+JSON.stringify(id)+']='+indices[value.capacity]);
writeFileSync(process.argv[3],'return {'+variants.join(',')+'}\n');
