-- Refined official-assets v3 production entry against the existing guarded mock controls.
-- STARTUP_DETAIL=1 enables observer counts and per-module/function timing.
local overlay = assert(os.getenv('STARTUP_ART'))
local mode = assert(os.getenv('STARTUP_WORKLOAD'))
local detail = os.getenv('STARTUP_DETAIL') == '1'
local mapOverlay = os.getenv('STARTUP_MAP')
local packaged = os.getenv('STARTUP_PAYLOAD')
local generated = os.getenv('STARTUP_GENERATED') or './build/lua'
package.path = (packaged and packaged .. '/?.lua;' or overlay .. '/?.lua;')
    .. (mapOverlay and mapOverlay .. '/?.lua;' or '') .. generated .. '/?.lua;'
    .. './src/lua/?.lua;' .. package.path

local function quietly(...)
    local msg = tostring(select(1,...))
    if msg:find('ABYSS_UI failed',1,true) or msg:find('phase=unavailable',1,true) then
        io.stderr:write(msg,'\n')
    end
end
print=quietly
local realRequire = require
local counts = {nativeCalls=0, propertyWrites=0, methods={}, properties={}}
local metrics = {requests=0, loads=0, GetChild=0, GroupLookup=0, MapLookup=0,
    created=0, destroyed=0, controlsCreated=0, frames=0}
local current, markRows, profileRows, callFrames, modules = '', {}, {}, {}, {}
local function phaseTimes()
    local wall, cpu = A_CLOCK()
    local currentBytes, peakBytes, peakRss, allocations, frees = A_MEMORY()
    return {wall,cpu,currentBytes,peakBytes,peakRss,allocations,frees}
end
local function mark(label)
    current=label
    markRows[#markRows+1]={label,phaseTimes(),metrics.requests,metrics.loads,metrics.GetChild,metrics.GroupLookup,
        metrics.MapLookup,metrics.created,metrics.destroyed,metrics.controlsCreated,metrics.frames,
        counts.nativeCalls,counts.propertyWrites}
end
A_MARK=mark
local function emit()
    for _, row in ipairs(markRows) do
        local out={'PHASE',row[1]}
        for i,val in ipairs(row[2]) do out[#out+1]=i<=2 and ('%.6f'):format(val) or ('%.0f'):format(val) end
        for i=3,#row do out[#out+1]=tostring(row[i]) end
        io.write(table.concat(out,'\t'),'\n')
    end
    for _,row in ipairs(profileRows) do
        io.write(('FUNCTION\t%s\t%s\t%.6f\t%.6f\n'):format(table.unpack(row)))
    end
    for _,row in ipairs(modules) do
        io.write(('MODULE\t%s\t%s\t%s\t%.6f\t%.6f\t%.6f\t%.6f\n'):format(table.unpack(row)))
    end
end
local function loadedArt()
    local catalogue=assert(package.loaded.abyss_monster_art_data)
    local n=0
    for _, asset in pairs(catalogue.assets) do
        if type(rawget(asset,'slots'))=='table' then n=n+1 end
    end
    return n
end
local function read(path)
    if A_READ then return A_READ(path) end
    local file=assert(io.open(path,'rb'))
    local source=file:read('*a')
    file:close()
    return source
end
local function replace(source, needle, replacement)
    local first, last = source:find(needle,1,true)
    assert(first, 'missing instrumentation anchor: '..needle)
    assert(not source:find(needle,last+1,true),'ambiguous instrumentation anchor: '..needle)
    return source:sub(1,first-1)..replacement..source:sub(last+1)
end
local function adjust(name,module)
    if name=='abyss_monster_actor_binding' then
        module.enabled=true;module.templateIndex=1;module.containerTemplateIndex=2;module.powerTemplateIndex=3
        module.templateIndexByDefinition={}
        for id,asset in pairs(A_TIER_BY_ID) do module.templateIndexByDefinition[id]=asset end
    elseif name=='abyss_traveler_portrait_assets' then
        module.imagePrefabId=7;module.containerPrefabId=2;module.selectionHalfImagePrefabId=8
    elseif name=='abyss_deck_browser_binding' then
        module.templateIndex=11
        for index,part in ipairs(module.parts)do part.templateIndex=11+index end
    end
end
local binders={abyss_monster_actor_binding=true,abyss_traveler_portrait_assets=true,abyss_deck_browser_binding=true}
local function profileCall(name, fn, ...)
    local wall0,cpu0=A_CLOCK()
    local phase=current
    local result=table.pack(fn(...))
    local wall,cpu=A_CLOCK()
    profileRows[#profileRows+1]={phase,name,wall-wall0,cpu-cpu0}
    return table.unpack(result,1,result.n)
end
local function enableProductionRequire()
    require=function(name)
        local cached=package.loaded[name]
        if detail then metrics.requests=metrics.requests+1 end
        if cached then return realRequire(name) end
        local wall0, cpu0, depth, parent, frame, phase
        if detail then
            wall0,cpu0=A_CLOCK()
            depth=#callFrames+1;parent=callFrames[depth-1]
            frame={name=name,wall=0,cpu=0};callFrames[depth]=frame
            phase=current
        end
        local module=realRequire(name)
        if detail then
            local wall,cpu=A_CLOCK()
            wall=wall-wall0;cpu=cpu-cpu0
            modules[#modules+1]={phase,parent and parent.name or '-',name,wall,cpu,wall-frame.wall,cpu-frame.cpu}
            if parent then parent.wall=parent.wall+wall;parent.cpu=parent.cpu+cpu end
            callFrames[depth]=nil
            metrics.loads=metrics.loads+1
        end
        if not packaged and binders[name] then adjust(name,module) end
        if detail and name=='abyss_map_ui' then
            local init=module.new
            module.new=function(...)return profileCall('MapUI.new',init,...)end
        elseif detail and name=='abyss_battle_ui' then
            local init=module.new
            module.new=function(...)return profileCall('BattleUI.new',init,...)end
        end
        return module
    end
end

if mode=='module' then
    local selected={'raven_adept','jaw_worm','acid_slime_m'}
    mark('module-begin')
    local loadCatalogue = assert(loadfile(overlay .. '/abyss_monster_art_data.lua'))
    mark('module-compiled')
    local art = loadCatalogue()
    package.loaded.abyss_monster_art_data=art
    mark('module-executed')
    io.write('DECODED\tmodule\t',loadedArt(),'\n')
    for _,id in ipairs(selected) do
        local wall,cpu=A_CLOCK()
        local slots=art.assets[id].slots
        local wall1,cpu1=A_CLOCK()
        assert(#slots>0)
        profileRows[#profileRows+1]={'module-first-access',id,wall1-wall,cpu1-cpu}
    end
    mark('module-first-access')
    io.write('DECODED\tfirst\t',loadedArt(),'\n')
    for _,id in ipairs(selected) do
        local wall,cpu=A_CLOCK()
        local slots=art.assets[id].slots
        local wall1,cpu1=A_CLOCK()
        assert(#slots>0)
        profileRows[#profileRows+1]={'module-repeat-access',id,wall1-wall,cpu1-cpu}
    end
    mark('module-repeat-access')
    emit()
    return
end

local layoutModules={abyss_ui_layout=true,abyss_ui_templates=true,abyss_deck_browser_binding=true}
local function copy(x)
    if type(x)~='table'then return x end
    local result={}
    for k,v in pairs(x) do result[k]=copy(v) end
    return result
end
-- The existing fixture also imports business modules for its other tests.
-- Supply local placeholders here so the offline native tree can exist before T1.
require=function(name)
    if layoutModules[name] then return realRequire(name) end
    if name=='abyss_combat' then return {copy=copy} end
    assert(name=='abyss_game_ui' or name=='abyss_nodes' or name=='abyss_data' or name=='abyss_presentation'
        or name=='abyss_viewport' or name=='abyss_theme' or name=='abyss_monster_surfaces',name)
    return {}
end
local fixturePath='tests/lua/support/game_ui_fixture.lua'
local fixtureText=read(fixturePath)
if detail then
    fixtureText=replace(fixtureText,'function Control:GetChild(name)',
        'function Control:GetChild(name) A_LOOKUP(self,name)')
    fixtureText=replace(fixtureText,'return NativeContract.control(self,spec)',
        'A_CONTROL(self); return NativeContract.control(self,spec)')
    local observe=dofile('scripts/runtime-baseline/observer.lua')
    function A_LOOKUP(control,name)
        metrics.GetChild=metrics.GetChild+1
        if control.name=='mapPanel' and name:match('^mapGroup%d+$') then
            metrics.GroupLookup=metrics.GroupLookup+1
        elseif control.name and control.name:match('^mapGroup%d+$') then
            metrics.MapLookup=metrics.MapLookup+1
        end
    end
    function A_CONTROL(control)
        metrics.controlsCreated=metrics.controlsCreated+1
        observe(control,counts)
    end
end
local F = assert(load(fixtureText,'@'..fixturePath))()
local Templates = realRequire('abyss_ui_templates')
local deckBinding = realRequire('abyss_deck_browser_binding')
package.loaded.abyss_deck_browser_binding=nil
require=realRequire

local variantDataPath=assert(os.getenv('STARTUP_TIERS'))
A_TIER_BY_ID=assert(loadfile(variantDataPath))()
local specs={
    [1]=Templates.AbyssMonsterActor,[2]=Templates.AbyssReadyCardGroup,[3]=Templates.AbyssMonsterPower,
    [4]=Templates.AbyssMonsterActor41,[5]=Templates.AbyssMonsterActor96,[6]=Templates.AbyssMonsterActor115,
    [7]=Templates.AbyssReadyCardImage,[8]=Templates.AbyssSelectionHalfTriangle,
    [11]=Templates.AbyssBattlePileCard,
}
for index,part in ipairs(deckBinding.parts) do specs[11+index]=Templates[part.name] end
for _,index in ipairs({1,2,3,4,5,6,7,8,11})do assert(specs[index],'missing fixture template index '..index)end
local artIndices={[4]=true,[5]=true,[6]=true}
local imageIndices={[7]=true,[8]=true}
if packaged then
    local names=assert(loadfile(assert(os.getenv('STARTUP_PACKAGED_TEMPLATES'))))()
    specs,artIndices,imageIndices={},{},{}
    for index,name in pairs(names)do
        specs[index]=assert(Templates[name],'missing packaged fixture template '..name)
        if name:match('^AbyssMonsterActor%d+$')then artIndices[index]=true end
        if name=='AbyssReadyCardImage' or name=='AbyssSelectionHalfTriangle' then imageIndices[index]=true end
    end
end
local Native = dofile('tests/lua/support/native_art_controls.lua')
local function activate(box, value) box.active=value; F.setEngineActive(box,value) end
local serial = 0
local actors=F.monsterActors()
local function markActive(box)
    box.SetActive=activate
    box.active=true
    return box
end
Enum={ImageSource={StaticReference='static'},ImageType={Basic=1,Stretch=2},
    CursorEventType={CursorClick='click',CursorDown='down',CursorUp='up'},
    Device={Desktop='desktop',Controller='controller',MobileController='mobileController',Mobile='mobile'}}
Color=setmetatable({FromRGBA=function(r,g,b,a)return {r=r,g=g,b=b,a=a}end},
    {__call=function(self,r,g,b,a)return self.FromRGBA(r,g,b,a)end})
game={GetUICanvasSize=function()return 1280,720 end,IsTestPlay=function()return true end,
    GetDevice=function()return 'desktop'end,GetCursorUIPos=function()return 0,0 end,
    InstantiateClientUIControl=function(index,parent)
        local spec=assert(specs[index],'bad template index '..tostring(index))
        local box=markActive(F.control(spec,parent))
        if artIndices[index] then Native.decorate(box:GetChild('monsterArt')) end
        if imageIndices[index] then Native.decorate(box) end
        serial=serial+1
        metrics.created=metrics.created+1
        parent.children['fixtureNative'..serial]=box
        return box
    end,
    DestroyClientUIControl=function(box)
        actors.destroy(box)
        metrics.destroyed=metrics.destroyed+1
    end,
    ServerSignal=function()return {SendSignal=function()end}end,
    PlayAudio2D=function()return 1 end}
local function setCanvas()
    local canvas=F.control({children=F.Layout})
    local stage=canvas:GetChild('stage')
    for _,path in ipairs({
        {'mapPanel'},{'nodePanel'},{'choicePanel'},{'battlePanel','hero','officialFigure'},
        {'characterPanel','traveler','officialAvatar'},{'characterPanel','details','officialSelectionFigure'},
    }) do
        local box=stage
        for _,name in ipairs(path) do box=assert(box:GetChild(name),name) end
        markActive(box)
    end
    script={object=canvas,GetParam=function(_,key)return key=='nativeBgmEnabled' end,
        EnableUpdate=function(self,value)self.updating=value end}
    return stage
end

local path=(packaged or 'src/lua')..'/abyss_ui.lua'
local function entryChunk()
    local entry=read(path)
    entry=replace(entry,'\n        view:resize(width, height)\n','\n        A_HOST=view\n        view:resize(width, height)\n')
    if detail then
        entry=replace(entry,'        local GameUI = require("abyss_game_ui")',
            '        A_MARK("startup-base-modules-begin")\n        local GameUI = require("abyss_game_ui")')
        entry=replace(entry,'        Viewport = require("abyss_viewport")\n        local width, height = game.GetUICanvasSize()',
            '        Viewport = require("abyss_viewport")\n        A_MARK("startup-base-modules-end")\n        local width, height = game.GetUICanvasSize()')
        entry=replace(entry,'        view = GameUI.new(stage,',
            '        A_MARK("startup-gameui-begin")\n        view = GameUI.new(stage,')
        entry=replace(entry,'        A_HOST=view','        A_MARK("startup-gameui-end")\n        A_HOST=view')
    end
    return entry
end
local function detailSource()
    local name='abyss_game_ui'
    local modulePath=(packaged or 'src/lua')..'/'..name..'.lua'
    package.preload[name]=function()
        local source=read(modulePath)
        local needle=packaged and 'owner . ready=true\nself:refresh()' or '    owner.ready = true\n    self:refresh()'
        local flag=packaged and 'owner . ready=true' or '    owner.ready = true'
        source=replace(source,needle,flag..'\nA_MARK("startup-menu-projection-begin")\nself:refresh()'
            ..'\nA_MARK("startup-menu-projection-end")')
        return assert(load(source,'@'..modulePath))()
    end
end
local function update()
    metrics.frames=metrics.frames+1
    OnUpdate(1/60)
    assert(script.updating and not A_HOST.disabled,'production OnUpdate disabled')
end
local function settle(label)
    for _=1,240 do
        if not A_HOST.pageReveal:covered() then return end
        update()
    end
    error('page failed to settle: '..label..' '..tostring(A_HOST.pageReveal.state))
end
local function startEntry(label,stage)
    mark(label..'-t1')
    assert(load(entryChunk(),'@'..path))()
    mark(label..'-entry-loaded')
    OnStart()
    assert(script.updating and A_HOST and A_HOST.mode=='menu','production OnStart failed')
    stage.ui=A_HOST
    mark(label..'-t2')
    settle('menu')
    local menu=stage:GetChild('menuPanel')
    local target=menu:GetChild('start')
    target=target.click and target or assert(target:GetChild('hit'))
    assert(menu.visible and target.visible and target.raycastTarget~=false and type(target.click)=='function',
        'menu Start unavailable after page gate')
    mark(label..'-t3')
end
local function combatEntry(stage)
    local host=A_HOST
    host.seed=1
    local menu=stage:GetChild('menuPanel')
    local start=menu:GetChild('start')
    start=start.click and start or start:GetChild('hit')
    assert(start.click())
    settle('selection')
    assert(host:selectCharacter('traveler'));settle('traveler')
    assert(host:selectElement('ironclad'));settle('element')
    assert(host:confirmCharacter());settle('opening')
    for _=1,240 do
        if not host.starting and not host.pageReveal:covered() and host.mode~='menu' then break end
        update()
    end
    if host.mode=='node' then
        for _,option in ipairs({1,2,1})do
            assert(F.click(stage,'nodePanel','eventView/option'..option))
            settle('Neow')
        end
    end
    assert(host.mode=='map' and host.run.phase=='map' and tostring(host.run.runSeed)=='1'
        and host.mapUI.navigationEnabled,'seeded route did not reach an interactive map')
    local Choices=require('abyss_nodes').available(host.run,host.map)
    local node=assert(Choices[1])
    local nodeSlot
    for slot,id in pairs(host.mapUI.slots)do if id==node.id then nodeSlot=slot;break end end
    assert(nodeSlot)
    local hit=F.mapControl(stage:GetChild('mapPanel'),'node'..nodeSlot)
    hit=hit.click and hit or assert(hit:GetChild('hit'))
    assert(hit.raycastTarget~=false)
    mark('first-fight-begin')
    local event={touchId=1}
    if hit.listeners.down then hit.listeners.down(event) end
    if hit.listeners.up then hit.listeners.up(event) end
    assert(hit.click(event))
    mark('first-fight-gesture')
    for _=1,240 do
        if host.mode=='battle' and host.run.phase=='combat' and not host.pageReveal:covered()
            and not host.battleUI.busy then break end
        update()
    end
    assert(host.mode=='battle' and host.run.phase=='combat' and not host.pageReveal:covered()
        and not host.battleUI.busy,'seeded battle did not become usable')
    mark('first-fight-ready')
    local surfaces=require('abyss_monster_surfaces').get(stage:GetChild('battlePanel'))
    local enemies, artSeen = {},0
    for _,enemy in ipairs(host.run.combat.enemies)do
        enemies[#enemies+1]=enemy.defId or enemy.definitionId or enemy.id
        local actor=assert(surfaces:find(enemy.id),'missing native actor')
        local art=assert(actor:GetChild('monsterArt'),'missing refined template art')
        assert(art.visible,'monster art did not render')
        artSeen=artSeen+1
    end
    io.write('FIGHT\t',node.id,'\t',table.concat(enemies,','),'\t',artSeen,'\n')
    io.write('DECODED\tfirst-fight\t',loadedArt(),'\n')
end

local stage = setCanvas()
if detail then detailSource() end
if packaged then package.path=packaged..'/?.lua' end
if _VERSION == 'Lua 5.4' and not packaged then
    -- This historical token boundary is accepted by repository Fengari but
    -- rejected by stock Lua 5.4. Normalize whitespace only for the offline lane.
    local modulePath='src/lua/abyss_event_combat_routes.lua'
    package.preload.abyss_event_combat_routes=function()
        local source=replace(read(modulePath),'floor<=6then','floor<=6 then')
        return assert(load(source,'@'..modulePath))()
    end
end
enableProductionRequire()
startEntry('cold',stage)
io.write('DECODED\tcold\t',loadedArt(),'\n')
combatEntry(stage)
actors.destroy(script.object)
OnDestroy()
stage,A_HOST,script=nil,nil,nil
local warmStage=setCanvas()
startEntry('warm',warmStage)
io.write('DECODED\twarm\t',loadedArt(),'\n')
OnDestroy()
emit()
