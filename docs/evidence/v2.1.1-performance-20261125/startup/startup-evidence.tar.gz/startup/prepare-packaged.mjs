import {createHash} from 'node:crypto';
import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {dirname,resolve} from 'node:path';

const [output,...receipts]=process.argv.slice(2).map(path=>resolve(path));
mkdirSync(output,{recursive:true});
const read=path=>JSON.parse(readFileSync(path));
const hash=content=>createHash('sha256').update(content).digest('hex');
const check=record=>{
  const data=readFileSync(record.path);
  if(data.length!==record.bytes||hash(data)!==record.sha256)throw Error('Receipt hash mismatch: '+record.path);
};
const all={};
for(const receipt of receipts){
  const final=read(receipt);
  if(hash(readFileSync(final.mapPath))!==final.sha256)throw Error('Final GIL hash mismatch: '+final.mapPath);
  check(final.sourceReceipt);
  const full=read(final.sourceReceipt.path);
  const {productionManifest,monsterActors,deckBrowser}=full;
  const byName=new Map(productionManifest.modules.map(file=>[file.name,file]));
  for(const file of productionManifest.modules)check(file);
  check(productionManifest.layout);check(productionManifest.templates);
  const payload=dirname(byName.get('abyss_ui').path);
  const generated=dirname(productionManifest.layout.path);
  const checkout=final.release?.version==='2.1.0'||final.sourceCommit.startsWith('55d6396c')?'live':'rc';
  if(all[checkout])throw Error('Duplicate packaged inputs');
  const portrait=readFileSync(byName.get('abyss_traveler_portrait_assets').path,'utf8');
  const number=name=>{
    const value=portrait.match(new RegExp('(?:^|\\n|,|[{])'+name+' ?= ?([0-9]+)'));
    if(!value)throw Error('missing '+name);
    return Number(value[1]);
  };
  const indexes={
    [monsterActors.templateIndex]:'AbyssMonsterActor',
    [monsterActors.powerTemplateIndex]:'AbyssMonsterPower',
    [monsterActors.containerTemplateIndex]:'AbyssReadyCardGroup',
    [number('imagePrefabId')]:'AbyssReadyCardImage',
    [number('selectionHalfImagePrefabId')]:'AbyssSelectionHalfTriangle',
    [deckBrowser.templateIndex]:'AbyssBattlePileCard',
  };
  if(number('containerPrefabId')!==monsterActors.containerTemplateIndex)throw Error('Different group binding');
  for(const [template,fields] of Object.entries(monsterActors.tiers)) indexes[fields.templateIndex]=template;
  for(const part of deckBrowser.parts) indexes[part.templateIndex]=part.name;
  const templatePath=resolve(output,checkout+'-packaged-templates.lua');
  const templatePairs=Object.entries(indexes).map(([idx,name])=>'['+idx+']='+JSON.stringify(name));
  writeFileSync(templatePath,'return {'+templatePairs.join(',')+'}\n');
  all[checkout]={receipt,receiptSha256:hash(readFileSync(receipt)),source:final.sourceCommit,
    candidate:final.sha256,payloadDigest:final.payloadDigest,buildId:final.buildId,
    payload,generated,templatePath,scriptCount:byName.size,
    module:byName.get('abyss_monster_art_data'),map:byName.get('abyss_map_ui'),
    layout:productionManifest.layout,templates:productionManifest.templates,indexes};
}
writeFileSync(resolve(output,'packaged-inputs.json'),JSON.stringify(all,null,2)+'\n');
console.log(Object.fromEntries(Object.entries(all).map(([key,f])=>[key,f.indexes])));
