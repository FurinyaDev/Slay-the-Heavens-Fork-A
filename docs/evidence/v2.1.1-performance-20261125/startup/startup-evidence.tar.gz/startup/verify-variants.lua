local directory=assert(os.getenv('STARTUP_VARIANTS'))
local function variant(name)
    return assert(loadfile(directory..'/'..name..'/abyss_monster_art_data.lua'))()
end
local function equal(left,right,path)
    assert(type(left)==type(right),path)
    if type(left)~='table' then assert(left==right,path);return end
    local total=0
    for key,value in pairs(left) do
        total=total+1
        equal(value,right[key],path..'/'..tostring(key))
    end
    for _ in pairs(right)do total=total-1 end
    assert(total==0,path)
end
local unpacked,eager,lazy=variant('uncompressed'),variant('eager'),variant('lazy')
local assets,primitives=0,0
for id,asset in pairs(lazy.assets)do
    assert(rawget(asset,'slots')==nil,'catalogue was decoded eagerly: '..id)
    local slots=asset.slots
    assert(rawequal(slots,asset.slots),'decoded geometry not cached: '..id)
    assets=assets+1;primitives=primitives+#slots
end
assert(assets==42 and primitives==3385)
equal(unpacked,eager,'eager')
equal(unpacked,lazy,'lazy')
print(('EQUIVALENCE_PASS assets=%d ordered_slots=%d'):format(assets,primitives))
