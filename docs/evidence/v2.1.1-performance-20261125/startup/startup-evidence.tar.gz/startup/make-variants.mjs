import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';

const [repository,live,rc,output] = process.argv.slice(2).map(path=>resolve(path));
mkdirSync(output,{recursive:true});
const load = (base,file) => import(pathToFileURL(resolve(base,file)));
const git = (cwd, args) => execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
const hash = content => createHash('sha256').update(content).digest('hex');

const {prepareRefinedReleaseMonsterArt,refinedReleaseMonsterRegistry} = await load(rc,'scripts/refined-release-monsters.mjs');
const {monsterActorTiers,monsterArtPayloadSource} = await load(rc,'scripts/monster-art.mjs');
const {monsterArtPayloadSource: eager} = await load(live,'scripts/monster-art.mjs');
const {toLua} = await load(rc,'scripts/build-lua-data.mjs');
const registry = readFileSync(resolve(rc,refinedReleaseMonsterRegistry));
const art = monsterActorTiers(prepareRefinedReleaseMonsterArt(JSON.parse(registry))).artData;
const dataFile = 'abyss_monster_art_data.lua';
const variantInfo = Object.fromEntries(Object.entries({
  uncompressed:`-- Generated from the bounded native monster registry.\nreturn ${toLua(art)}\n`,
  eager:eager(art),
  lazy:monsterArtPayloadSource(art)
}).map(([variant,source])=>{
  const dir = resolve(output,variant);
  mkdirSync(dir,{recursive:true});
  writeFileSync(resolve(dir,dataFile),source);
  return [variant,{bytes:Buffer.byteLength(source),sha256:hash(source)}];
}));
for(const [tree,variant] of [[live,'eager'],[rc,'lazy']]) {
  const emitted = readFileSync(resolve(tree,'build/lua',dataFile));
  if(hash(emitted)!==variantInfo[variant].sha256) throw Error('Formal UI generation differs from measured '+variant);
}
const mapPath='src/lua/abyss_map_ui.lua';
const mapBefore=readFileSync(resolve(rc,mapPath));
const after='f10eefa27c75788cf0b753d5e9121e3887114218';
if(git(repository,['rev-parse',after+'^{commit}'])!==after) throw Error('missing hotfix commit');
const mapAfter=execFileSync('git',['show',after+':'+mapPath],{cwd:repository});
const oldAtParent=execFileSync('git',['show',after+'^:'+mapPath],{cwd:repository});
if(!mapBefore.equals(oldAtParent))throw Error('map before differs from canonical hotfix parent');
mkdirSync(resolve(output,'map-after'),{recursive:true});
writeFileSync(resolve(output,'map-after','abyss_map_ui.lua'),mapAfter);
const metadata={
  sourceCommit:{live:git(live,['rev-parse','HEAD']), priorRC:git(rc,['rev-parse','HEAD']), hotfix:after,
    hotfixParent:git(repository,['rev-parse',after+'^']), exactPublishedGIL:git(repository,['rev-parse','55d6396c'])},
  sourceTree:{live:git(live,['rev-parse','HEAD^{tree}']),priorRC:git(rc,['rev-parse','HEAD^{tree}']),
    hotfixParent:git(repository,['rev-parse',after+'^^{tree}']),
    hotfix:git(repository,['rev-parse',after+'^{tree}']), exactPublishedGIL:git(repository,['rev-parse','55d6396c^{tree}'])},
  profile:'official-assets-battle-v3/native-page-lifecycle',
  variantInfo,
  mapBefore:hash(mapBefore),mapAfter:hash(mapAfter),
  registrySha256:hash(registry),
  assets:Object.fromEntries(Object.entries(art.assets).map(([id,s])=>[id,{slots:s.slots.length,capacity:s.capacity,geometrySha256:s.geometrySha256}])),
  binding:art.bindings,
  generated:Object.fromEntries(['abyss_ui_layout.lua','abyss_ui_templates.lua','abyss_traveler_portrait_assets.lua','abyss_art_features.lua','abyss_ui_profile.lua'].map(file=>[file,
    Object.fromEntries([['live',live],['priorRC',rc]].map(([label,tree])=>{
      const body=readFileSync(resolve(tree,'build/lua',file));return [label,{bytes:body.length,sha256:hash(body)}];
    }))
  ]))
};
writeFileSync(resolve(output,'variant-metadata.json'),JSON.stringify(metadata,null,2)+'\n');
console.log(metadata.sourceCommit,variantInfo,'slots',Object.values(metadata.assets).reduce((n,a)=>n+a.slots,0));
