"""Render the measured packed-Lua startup waterfall plus platform boundaries."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import fontManager
from matplotlib.patches import FancyBboxPatch

COLORS = ['#708ba5','#9eacc2','#12396a','#337e95','#956124','#d09245','#c1a076','#9e8f71','#4c8268']
RUNS = [('deployed-live-eager-detailed','v2.1.0  55d6396c'),
        ('cd-hotfix-lazy-detailed','v2.1.1  b6ba4614')]
PHASES = ['Lua 入口','OnStart 入口','基础模块与数据','视口及美术资源对象',
    'GameUI 构造和输入绑定','主菜单 Lua 投影','GameUI 收尾','Resize 与启用更新','菜单门控与交互就绪']
INK='#1b293d'
MUTED='#586b80'

def timeline(ax, data, mode):
    totals=[]
    for i,(key,label) in enumerate(RUNS):
        stages=data['waterfall'][key][mode]
        elapsed=0
        for n,stage in enumerate(stages):
            width=stage['wallMs']['p50']
            ax.barh(i,width,left=elapsed,color=COLORS[n],height=.36,linewidth=0)
            if width>sum(s['wallMs']['p50'] for s in stages)*.11:
                ax.text(elapsed+width/2,i,f'{width:.1f}',va='center',ha='center',color='white',fontsize=9)
            elapsed+=width
        ax.text(elapsed+.015*elapsed,i,f'{elapsed:.1f}',va='center',color=INK,fontsize=9)
        totals.append(elapsed)
    ax.set_xlim(0,max(totals)*1.12)
    ax.set_yticks([0,1],[value for _,value in RUNS],fontsize=10)
    ax.invert_yaxis()
    ax.set_ylim(1.64,-.57)
    ax.set_xlabel('离线墙钟耗时，毫秒，阶段 P50 累加',fontsize=9,color=MUTED)
    ax.grid(axis='x',alpha=.2)
    ax.set_axisbelow(True)
    ax.tick_params(axis='both',length=0,labelcolor=MUTED)
    for side in ax.spines.values():
        side.set_visible(False)

def boundary(ax):
    ax.axis('off')
    boxes=[
        (.00,.22,'T0 玩家点击进入奇域','平台下载或缓存，原生资源准备','UNVERIFIED'),
        (.255,.22,'T1 Lua 入口','执行入口脚本和同步 OnStart','离线测量'),
        (.51,.22,'T2 OnStart 完成','进入 Lua 菜单就绪门控','离线测量'),
        (.765,.235,'T3 菜单可操作','真实首帧绘制及触控响应','Lua 模拟 / 实机 UNVERIFIED')
    ]
    for x,w,title,body,status in boxes:
        fill='#f3f5f8' if 'UNVERIFIED' in status else '#eaf4f2'
        box=FancyBboxPatch((x,.12),w,.77,boxstyle='round,pad=0.008,rounding_size=.018',
            linewidth=0,facecolor=fill,transform=ax.transAxes,clip_on=False)
        ax.add_patch(box)
        ax.text(x+.014,.67,title,transform=ax.transAxes,color=INK,fontsize=10,weight='bold')
        ax.text(x+.014,.44,body,transform=ax.transAxes,color=MUTED,fontsize=8.1)
        ax.text(x+.014,.24,status,transform=ax.transAxes,color='#8b5e20' if 'UNVERIFIED' in status else '#31665a',fontsize=8)
    for x in [.235,.49,.745]:
        ax.text(x,.50,'→',transform=ax.transAxes,ha='center',va='center',color=MUTED,fontsize=11)

def rounded(value):
    return f'{value:.1f}'

def phase_table(ax,data):
    ax.axis('off')
    columns=[.47,.62,.77,.92]
    for x,title in zip(columns,['线上源 冷','热修复 冷','线上源 暖','热修复 暖']):
        ax.text(x,.94,title,ha='right',va='center',fontsize=9,color=INK,weight='bold',transform=ax.transAxes)
    for index,(name,color) in enumerate(zip(PHASES,COLORS)):
        y=.84-index*.084
        if index%2==0:
            ax.add_patch(plt.Rectangle((.0,y-.041),.955,.082,transform=ax.transAxes,facecolor='#f5f7fa',edgecolor='none'))
        ax.add_patch(plt.Rectangle((.015,y-.012),.012,.024,transform=ax.transAxes,facecolor=color,edgecolor='none'))
        ax.text(.045,y,name,va='center',fontsize=9,color=INK,transform=ax.transAxes)
        measurements=[data['waterfall'][key][mode][index] for mode in ['cold','warm'] for key,_ in RUNS]
        for x,result in zip(columns,measurements):
            ax.text(x,y,rounded(result['wallMs']['p50']),ha='right',va='center',fontsize=9,color=INK,
                transform=ax.transAxes)
    ax.text(.015,.075,'T1→T2 为同步阻塞。T2→T3 使用手动推进的 Lua OnUpdate，菜单以页面门控打开及可用 Start 命令判定。',
        va='center',fontsize=8.5,color=MUTED,transform=ax.transAxes)
    ax.text(.015,.019,'冷为新 VM，暖为同一 VM、模块已载入、模拟原生界面重建。图表基于每侧 10 次详细探针，含诊断开销。',
        va='center',fontsize=8.5,color=MUTED,transform=ax.transAxes)

def init_fonts():
    from fontTools import subset
    directory=Path(matplotlib.get_cachedir())
    font_directory=Path('/usr/share/fonts/opentype/noto')
    for weight in ['Regular','Bold']:
        ttc=font_directory/f'NotoSansCJK-{weight}.ttc'
        if not ttc.exists():
            raise FileNotFoundError('Install Noto Sans CJK font collections to reproduce this graph.')
        options=subset.Options()
        options.font_number=2
        font=subset.load_font(str(ttc),options)
        selected=subset.Subsetter(options=options)
        selected.populate(text=Path(__file__).read_text()+''.join(chr(c) for c in range(32,127)))
        selected.subset(font)
        output=directory/f'waterfall-noto-sans-sc-{weight}.otf'
        subset.save_font(font,str(output),options)
        fontManager.addfont(output)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('summary',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    data=json.loads(args.summary.read_text())
    init_fonts()
    plt.rcParams.update({'font.family':['Noto Sans CJK SC','DejaVu Sans'],'svg.fonttype':'path','axes.unicode_minus':False})
    fig=plt.figure(figsize=(12.6,8.1),facecolor='white')
    grid=fig.add_gridspec(5,1,height_ratios=[.34,1.04,1,1,2.9],hspace=.42,
        left=.165,right=.963,top=.89,bottom=.055)
    fig.text(.055,.955,'启动瀑布图',fontsize=24,weight='bold',color=INK)
    fig.text(.055,.920,'有声 GIL 的生产 Lua · 公开构建夹具 · 同源布局及模板 · Lua 5.4',fontsize=10,color=MUTED)
    ax=fig.add_subplot(grid[0:2,0])
    p=ax.get_position()
    ax.set_position([.055,p.y0,.908,p.height])
    boundary(ax)
    for i,mode in enumerate(['cold','warm'],2):
        ax=fig.add_subplot(grid[i,0])
        ax.set_title('冷启动' if mode=='cold' else '暖启动',loc='left',color=INK,fontsize=11,fontweight='bold',pad=6)
        timeline(ax,data,mode)
    ax=fig.add_subplot(grid[4,0])
    p=ax.get_position()
    ax.set_position([.055,p.y0,.908,p.height])
    phase_table(ax,data)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(args.output,metadata={'Title':'Startup Waterfall','Description':'Measured offline packed Lua with platform timestamps unverified.'})

if __name__=='__main__':
    main()
