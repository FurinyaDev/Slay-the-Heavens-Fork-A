// Cross-check using the repository's unmodified Fengari Lua parser and runtime.
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {resolve} from 'node:path';

const require=createRequire(resolve('package.json'));
const {lua,lauxlib,lualib,to_luastring,to_jsstring}=require('fengari');
const state=lauxlib.luaL_newstate();
lualib.luaL_openlibs(state);
let heapPeak=0;
function global(name, fn) {
  lua.lua_pushjsfunction(state,fn);
  lua.lua_setglobal(state,to_luastring(name));
}
global('A_CLOCK',l=>{
  const cpu=process.cpuUsage();
  lua.lua_pushnumber(l,performance.now());
  lua.lua_pushnumber(l,(cpu.user+cpu.system)/1000);
  return 2;
});
global('A_MEMORY',l=>{
  const mem=process.memoryUsage();
  heapPeak=Math.max(heapPeak,mem.heapUsed);
  for(const value of [mem.heapUsed,heapPeak,process.resourceUsage().maxRSS,0,0]) lua.lua_pushnumber(l,value);
  return 5;
});
global('A_READ',l=>{
  lua.lua_pushstring(l,readFileSync(to_jsstring(lua.lua_tostring(l,1))));
  return 1;
});
if(lauxlib.luaL_dofile(state,to_luastring(process.argv[2]))!==lua.LUA_OK) {
  console.error(to_jsstring(lua.lua_tostring(state,-1)));
  process.exitCode=1;
}
