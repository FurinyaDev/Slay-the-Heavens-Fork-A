"""Interleave exact production probes and preserve every result, including failures."""
import argparse
import json
import os
from pathlib import Path
import platform
import random
import subprocess
import sys
import time

DIR = Path(__file__).resolve().parent
VARIANTS = DIR / 'variants'
PHASE_FIELDS = [
    'wallMs', 'cpuMs', 'luaBytes', 'luaPeakBytes', 'processPeakRSSKiB', 'allocations', 'frees',
    'requireCalls', 'moduleLoads', 'getChild', 'mapGroupLookups', 'mapMemberLookups', 'templateCreates',
    'templateDestroys', 'controlsCreated', 'frameCallbacks', 'observedNativeCalls', 'observedPropertyWrites'
]
HOST_MAIN = [
    ('live-eager', 'live', 'eager', False, False),
    ('rc-uncompressed', 'rc', 'uncompressed', False, False),
    ('rc-eager', 'rc', 'eager', False, False),
    ('rc-lazy', 'rc', 'lazy', False, False),
    ('hotfix-lazy', 'rc', 'lazy', True, False),
]
HOST_DETAIL = [
    ('rc-lazy', 'rc', 'lazy', False, False),
    ('rc-lazy-detailed', 'rc', 'lazy', False, True),
    ('hotfix-lazy-detailed', 'rc', 'lazy', True, True),
    ('live-eager-detailed', 'live', 'eager', False, True),
]
PACKAGED = [
    ('deployed-live-eager', 'live', 'eager', False, False),
    ('cd-hotfix-lazy', 'rc', 'lazy', False, False),
]
PACKAGED_DETAIL = [
    ('deployed-live-eager-detailed', 'live', 'eager', False, True),
    ('cd-hotfix-lazy-detailed', 'rc', 'lazy', False, True),
]
MODULES = [(name, 'rc', name, False, False) for name in ('uncompressed', 'eager', 'lazy')]

def parse_rows(lines):
    phases, functions, modules, decoded, fight = [], [], [], {}, None
    for line in lines.splitlines():
        key, *fields = line.split('\t')
        if key == 'PHASE':
            phase, *values = fields
            assert len(PHASE_FIELDS) == len(values), line
            phases.append({'phase':phase, **{name:float(value) for name,value in zip(PHASE_FIELDS,values)}})
        elif key == 'MODULE':
            phase,parent,name,wall,cpu,own_wall,own_cpu = fields
            modules.append({'phase':phase,'parent':parent,'name':name,'inclusiveWallMs':float(wall),
                'inclusiveCPUMs':float(cpu),'exclusiveWallMs':float(own_wall),'exclusiveCPUMs':float(own_cpu)})
        elif key == 'FUNCTION':
            phase,name,wall,cpu = fields
            functions.append({'phase':phase,'name':name,'wallMs':float(wall),'cpuMs':float(cpu)})
        elif key == 'DECODED':
            phase,count = fields
            decoded[phase] = int(count)
        elif key == 'FIGHT':
            node,enemies,rendered = fields
            fight={'node':node,'enemies':enemies.split(','),'rendered':int(rendered)}
    return {'phases':phases,'functions':functions,'modules':modules,'decodedAssets':decoded,'fight':fight}

def run_sample(cell, workload, round_id, order, backend, packaged=False):
    label, checkout, variant, map_after, detail = cell
    env = {**os.environ, 'STARTUP_ART':str(VARIANTS/variant),'STARTUP_WORKLOAD':workload,
        'STARTUP_TIERS':str(VARIANTS/'tier-by-id.lua'),'STARTUP_DETAIL':str(int(detail))}
    for name in ['STARTUP_MAP','STARTUP_PAYLOAD','STARTUP_GENERATED','STARTUP_PACKAGED_TEMPLATES']:
        env.pop(name,None)
    if packaged:
        input_info=json.loads((VARIANTS/'packaged-inputs.json').read_text())[checkout]
        env.update(STARTUP_PAYLOAD=input_info['payload'],STARTUP_GENERATED=input_info['generated'],
            STARTUP_PACKAGED_TEMPLATES=input_info['templatePath'])
    if map_after:
        env['STARTUP_MAP'] = str(VARIANTS/'map-after')
    script = DIR/'startup-workload.lua'
    command = [str(DIR/'lua54-trace'),str(script)] if backend == 'lua54' else ['node',str(DIR/'fengari-trace.mjs'),str(script)]
    began = time.monotonic_ns()
    row = {'variant':label, 'checkout':checkout, 'encoding':variant, 'mapLookupCache':map_after,
        'detail':detail, 'packaged':packaged, 'round':round_id, 'order':order, 'workload':workload, 'backend':backend}
    if packaged:
        row.update(sourceCommit=input_info['source'], payloadDigest=input_info['payloadDigest'],
            candidateSha256=input_info['candidate'], buildId=input_info['buildId'])
    try:
        proc = subprocess.run(command,cwd=DIR/checkout,env=env,timeout=45,capture_output=True,text=True)
        parsed = parse_rows(proc.stdout)
        passed = proc.returncode == 0 and len(parsed['phases']) > 0
        row.update(status='PASS' if passed else 'FAIL', returncode=proc.returncode,
            elapsedProcessMs=(time.monotonic_ns()-began)/1e6, **parsed)
        if not passed or proc.stderr:
            row.update(rawStdout=proc.stdout, stderr=proc.stderr)
    except subprocess.TimeoutExpired as err:
        row.update(status='TIMEOUT', stderr=(err.stderr or b'').decode(errors='replace'),
            rawStdout=(err.stdout or b'').decode(errors='replace'))
    except (AssertionError, ValueError) as err:
        row.update(status='PARSE_ERROR', error=repr(err))
    return row

def cgroup():
    return {name:Path(f'/sys/fs/cgroup/{name}').read_text().strip()
        for name in ['cpu.max','cpu.stat','memory.max','memory.current','cpuset.cpus.effective']}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('lane', choices=['module','host','detail','packaged','packaged-detail'])
    parser.add_argument('output', type=Path)
    parser.add_argument('--rounds', type=int, default=24)
    parser.add_argument('--cpu', type=int, default=4)
    parser.add_argument('--backend', choices=['lua54','fengari'], default='lua54')
    args=parser.parse_args()
    os.sched_setaffinity(0,{args.cpu})
    cells={'module':MODULES,'host':HOST_MAIN,'detail':HOST_DETAIL,
        'packaged':PACKAGED,'packaged-detail':PACKAGED_DETAIL}[args.lane]
    packaged=args.lane.startswith('packaged')
    workload='module' if args.lane=='module' else 'host'
    output=args.output
    seed=2110953954
    rng=random.Random(seed)
    started=time.time()
    start_cgroup=cgroup()
    failures=0
    with output.open('w') as sink:
        for round_id in range(args.rounds):
            if round_id%len(cells)==0:
                order=cells[:]
                rng.shuffle(order)
                if round_id//len(cells)%2:
                    order.reverse()
            skip=round_id%len(cells)
            interleaved=order[skip:]+order[:skip]
            for position,cell in enumerate(interleaved,1):
                sample=run_sample(cell,workload,round_id+1,position,args.backend,packaged)
                sink.write(json.dumps(sample,ensure_ascii=False)+'\n')
                sink.flush()
                if sample['status'] != 'PASS':
                    failures+=1
                    print('FAIL',round_id+1,cell[0],sample.get('stderr'),flush=True)
            if (round_id+1)%5==0 or round_id+1==args.rounds:
                print(args.lane,round_id+1,'/',args.rounds,'failures',failures,flush=True)
    meta={'lane':args.lane,'backend':args.backend,'sampleCount':args.rounds*len(cells),
        'failed':failures,'randomizationSeed':seed,'workloadRunSeed':1,
        'affinityCPUs':sorted(os.sched_getaffinity(0)), 'hostname':platform.node(),
        'platform':platform.platform(),'startedUnix':started,'endedUnix':time.time(),
        'resourceStart':start_cgroup,'resourceEnd':cgroup()}
    output.with_suffix('.metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    return int(failures>0)

if __name__=='__main__':
    sys.exit(main())
