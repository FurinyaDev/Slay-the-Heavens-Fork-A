from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parent
candidate=root/'candidate'
original='6492e8dccbcf847a0eba7ad3995da50257032e08'
live='eb64f4e6cd45198118e123b6640dc491f186e329'
intermediate='581d066538e4aee1bbd5735eaecd4bf58ee9af1a'
original_deck={name:original for name in ['abyss_deck_ui.lua','abyss_deck_browser.lua']}
variants={'hotfix':original_deck,'no-map-cache':original_deck|{'abyss_map_ui.lua':live},
          'no-enemy-cache':original_deck|{'abyss_battle_render_actors.lua':live},
          'fixed':{name:intermediate for name in original_deck},'final':{}}
for name,changed in variants.items():
    destination=root/'default-variants'/name
    destination.mkdir(parents=True)
    for directory in ('build','scripts','node_modules','tests'):
        (destination/directory).symlink_to(candidate/directory)
    source=destination/'src'/'lua'
    shutil.copytree(candidate/'src'/'lua',source)
    for file,sha in changed.items():
        content=subprocess.check_output(['git','-C',str(candidate),'show',f'{sha}:src/lua/{file}'])
        (source/file).write_bytes(content)
