# Reproduce the exact deck-only follow-up

This package records the live `eb64f4e6cd45198118e123b6640dc491f186e329`, prior Hotfix `6492e8dccbcf847a0eba7ad3995da50257032e08`, intermediate patch `581d066538e4aee1bbd5735eaecd4bf58ee9af1a`, and final scope `722555e56c23b4b89f00af2f5b91a268536afd8a`. The local Git history can be reproduced by applying `exact-deck-fixes.patch` with `git am` to the prior Hotfix. Local recommit identities depend on the committer. The before/after overlay swaps only the two changed production owners. Tests, UI model, fixture actor bindings, workload, and runtime binaries are shared within each compare.

## Build profiles

Start in this directory with detached `live` and `candidate` (final) worktrees and provision the official build inputs via the repository's Git LFS instructions. The default generated profile shares the final candidate's generated asset directory among all Hotfix slices; `live` independently generated its own default profile and differs in release narrative metadata only. The full production UI profile is a standard native export shape with simulated template handles via `bind-fixtures.mjs`.

```sh
(cd live && npm ci --ignore-scripts && npm run build:data && npm run build:ui)
(cd candidate && npm ci --ignore-scripts && npm run build:data && npm run build:ui)
(cd candidate && mkdir -p build/profile-ui && node scripts/build-lua-data.mjs data build/profile-ui/abyss_data.lua && node scripts/build-ui.mjs build/profile-ui --official-assets --native-page-lifecycle --refined-release-monsters && node ../bind-fixtures.mjs build/profile-ui)
python prepare-worker-variants.py
```

The recorded binaries were texlua (LuaTeX 1.18.0, Lua 5.3) and Node 24.22.3. Full native map loop pins the first allowed CPU and default worker pins the last. Hosted data used the existing Docker-pinned workflow; local managed Docker had driver `none`. The main native trace uses `run-runtime-profile.py` unchanged from its first report. `baseline-overlay` contains the two pre-fix modules.

```sh
python run-runtime-profile.py --out raw-native-repro --rounds 7 --modes bare trace --observer candidate/scripts/runtime-baseline/observer.lua --arm prior:candidate:baseline-overlay --arm fixed:candidate
python run-map-loop.py --out raw-map-loop-repro
python run-default-worker.py --samples 5 --output raw-default-slices-repro
python run-default-worker.py --samples 3 --output raw-default-final-repro --arms hotfix final
python summarize.py --native raw-native-repro --worker raw-default-final-repro --map raw-map-loop-repro --out evidence-repro
(cd candidate && node --test --test-concurrency=1 tests/deck-pages.test.mjs)
(cd candidate && texlua ../run-lua.lua ../legacy-sort-contract.lua)
```

The `hosted/report.json` is read directly from GitHub Actions Artifact 14983519087, report `45528828838` attempt 1. Its declared ZIP digest is `sha256:9e619fc01396cd42059d3a51ccea783bf7b5019e7efad5328bc162e40f94531f`. The archived extract's SHA-256 is `a22d74785b5dee63fce68ad0e1d451c8b161bfe5ef770bac9202c9ac384eb924`. CSV data use P50 of paired differences where explicitly marked in the report, and independent medians elsewhere.
