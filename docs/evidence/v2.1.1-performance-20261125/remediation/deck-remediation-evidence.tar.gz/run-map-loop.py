import argparse
from pathlib import Path
import json
import os
import subprocess

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--out',type=Path,default=root/'raw-map-loop')
out=parser.parse_args().out.resolve();out.mkdir(exist_ok=True)
cpu=sorted(os.sched_getaffinity(0))[0]
with (out/'runs.jsonl').open('x') as runs:
    for i in range(12):
        for arm in (('prior','fixed') if i%2==0 else ('fixed','prior')):
            file=out/f'{i+1:02}-{arm}.txt'
            env=dict(os.environ,DECK_SOURCE=str(root/'baseline-overlay') if arm=='prior' else 'src/lua',
                     DECK_GENERATED='build/profile-ui',DECK_AMOUNT='75',DECK_SAMPLES='1',DECK_CYCLES='40')
            r=subprocess.run(['taskset','-c',str(cpu),'texlua',str(root/'deck-map-loop-probe.lua')],cwd=root/'candidate',
                             env=env,capture_output=True,text=True,timeout=30,check=False)
            file.write_text(r.stdout+r.stderr)
            prefix='LOOP_CPU\t'
            cpu_ms=next((float(line.removeprefix(prefix)) for line in r.stdout.splitlines() if line.startswith(prefix)),None)
            row={'arm':arm,'round':i+1,'exit':r.returncode,'file':file.name,'pinnedCore':cpu,'cpuMs40Reopens':cpu_ms}
            runs.write(json.dumps(row)+'\n');runs.flush();print(json.dumps(row),flush=True)
