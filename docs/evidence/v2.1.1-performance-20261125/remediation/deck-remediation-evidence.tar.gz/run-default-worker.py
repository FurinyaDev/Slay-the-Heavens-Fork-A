from pathlib import Path
import argparse
import json
import os
import subprocess
import time

p=argparse.ArgumentParser()
p.add_argument('--samples',type=int,default=4)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--arms',nargs='+',default=['live','hotfix','no-map-cache','no-enemy-cache','fixed'])
a=p.parse_args()
root=Path(__file__).resolve().parent
out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
variants=[(name,root/'live' if name=='live' else root/'default-variants'/name) for name in a.arms]
cpus=sorted(os.sched_getaffinity(0))
with (out/'runs.jsonl').open('x') as f:
    for cycle in range(a.samples):
        start_at=cycle%len(variants)
        order=variants[start_at:]+variants[:start_at]
        if cycle%2: order=list(reversed(order))
        for name,cwd in order:
            file=out/f'{cycle+1:02}-{name}.txt'
            begin=time.monotonic()
            with file.open('x') as raw:
                try:
                    result=subprocess.run(['taskset','-c',str(cpus[-1]),'node','scripts/runtime-baseline/worker.mjs'],cwd=cwd,
                                          timeout=60,stdout=raw,stderr=subprocess.STDOUT,check=False)
                    code=result.returncode
                except subprocess.TimeoutExpired:
                    code='TIMEOUT'
            s=file.read_text(errors='replace')
            row={'round':cycle+1,'arm':name,'file':file.name,'wallSeconds':time.monotonic()-begin,
                 'pinnedCore':cpus[-1],'exit':code,'ok':code==0 and 'RUNTIME_BASELINE_PASS seed=1 idleFrames=300' in s}
            f.write(json.dumps(row)+'\n');f.flush();print(json.dumps(row),flush=True)
