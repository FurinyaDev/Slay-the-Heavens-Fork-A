local overlay=os.getenv('LUA_SOURCE_OVERLAY') or 'src/lua'
local generated=os.getenv('LUA_GENERATED') or 'build/lua'
package.path=generated..'/?.lua;'..overlay..'/?.lua;src/lua/?.lua;'..package.path
dofile(assert(arg[1]))
