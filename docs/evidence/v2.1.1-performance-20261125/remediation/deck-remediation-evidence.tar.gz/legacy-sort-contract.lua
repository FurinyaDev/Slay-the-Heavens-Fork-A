local F=dofile('tests/lua/support/game_ui_fixture.lua')
local host,root=F.fixture()
assert(F.start(host))
local deck=host.deckUI
local panel=root:GetChild('deckPanel')
local function check(mode,isSelected,text)
    local control=panel:GetChild('sort'..mode)
    assert(control.visible and control:GetChild('selected').visible==isSelected)
    for _,state in ipairs({'normal','hover','pressed','disabled'})do
        assert(control:GetChild('hit'):GetChild(state):GetChild('label').text==text)
    end
end
assert(host:openDeck());host:update(0)
check('original',true,'获得顺序 ↑')
check('type',false,'类型')
assert(deck:setSort('cost'));host:update(0)
check('original',false,'获得顺序')
check('cost',true,'耗能 ↑')
assert(deck:setSort('cost'));host:update(0)
check('cost',true,'耗能 ↓')
assert(deck:showText('示例','文本'))
for _,mode in ipairs({'original','type','cost'})do
    local control=panel:GetChild('sort'..mode)
    assert(not control.visible and not control:GetChild('selected').visible)
end
assert(deck:back());host:update(0)
check('cost',true,'耗能 ↓')
assert(host:closeDeck());assert(host:openDeck());host:update(0)
check('cost',true,'耗能 ↓')
assert(host:closeDeck())
print('LEGACY_SORT_CONTRACT_PASS')
