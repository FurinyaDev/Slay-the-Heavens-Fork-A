import argparse
from pathlib import Path
from collections import defaultdict
import csv
import json
from statistics import median

root=Path(__file__).resolve().parent
arguments=argparse.ArgumentParser()
arguments.add_argument('--native',default='raw-native-final')
arguments.add_argument('--worker',default='raw-default-final')
arguments.add_argument('--map',default='raw-map-loop-final')
arguments.add_argument('--out',type=Path,default=root/'evidence')
args=arguments.parse_args()
out=args.out;out.mkdir(exist_ok=True)


def manifest(name):
    directory=root/name
    for row in map(json.loads,(directory/'runs.jsonl').read_text().splitlines()):
        yield row,(directory/row['file']).read_text(errors='replace').splitlines()


def write_csv(name,rows):
    with (out/name).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def metrics(values):
    return {'n':len(values),'p50':median(values),'max':max(values),'min':min(values),'samples':values}


def group(rows,keys,columns):
    groups=defaultdict(list)
    for row in rows:
        groups[tuple(row[k] for k in keys)].append(row)
    return [dict(zip(keys,key))|{name:metrics([row[name] for row in r]) for name in columns} for key,r in groups.items()]


def pair(rows,before,after,keys,columns):
    grouped=defaultdict(dict)
    for row in rows:
        grouped[tuple(row[key] for key in keys)][row['arm'],row['round']]=row
    result=[]
    for keys_now,items in grouped.items():
        rounds={number for arm,number in items if (before,number) in items and (after,number) in items}
        if not rounds: continue
        record=dict(zip(keys,keys_now))
        for c in columns:
            deltas=[items[after,k][c]-items[before,k][c] for k in sorted(rounds)]
            record[c+'_delta']=metrics(deltas)|{'improved':sum(d<0 for d in deltas)}
        result.append(record)
    return result


def number(value):
    return float(value)


native=[]; native_trace=[]; native_decks=[]
trace_fields=['wall_ms','cpu_ms','lua_kib','rss_kib','rss_hwm_kib','created','destroyed','alive','roots','parts',
              'sdk','property_writes','get_child','set_visible']
phase_fields=['cpu_ms','wall_ms','updates','peak_update_ms']
deck_fields=['roots_before','parts_before','new_roots','new_parts','click_cpu_ms','uncovered_round','first_round','ready_round','first_cpu_ms']
for run,lines in manifest(args.native):
    if not run['complete']: continue
    common={k:run[k] for k in ('arm','round','mode')};begin={}
    for l in lines:
        fields=l.split('\t')
        if fields[0]=='TRACE':
            phase,event=fields[2:4]; values=list(map(number,fields[4:]))
            if event=='begin':begin[phase]=values
            elif event=='end':native_trace.append(common|{'phase':phase}|dict(zip(trace_fields,[b-a for a,b in zip(begin[phase],values)])))
        elif fields[0]=='PHASE':native.append(common|{'phase':fields[1]}|dict(zip(phase_fields,map(number,fields[2:]))))
        elif fields[0]=='DECK':native_decks.append(common|{'phase':fields[1]}|dict(zip(deck_fields,map(number,fields[2:]))))

worker=[]
for run,lines in manifest(args.worker):
    if not run['ok']:continue
    sample=next((json.loads(line.split(' ',1)[1]) for line in lines if line.startswith('RUNTIME_BASELINE_JSON ')),None)
    if not sample: continue
    row=next(r for r in sample['rows'] if r['phase']=='deck-roundtrip')
    worker.append({k:run[k] for k in ('arm','round','pinnedCore')}|{k:row[k] for k in ('elapsedMs','nativeCalls','propertyWrites','snapshots','moduleLoads')})

loops=[row for row,_ in manifest(args.map) if row['exit']==0 and row['cpuMs40Reopens'] is not None]
hosted_rows=[]; hosted=json.loads((root/'hosted'/'report.json').read_text())
for tier,data in hosted['results'].items():
    for arm in ('baseline','candidate'):
        for round_number,record in enumerate(data[arm]['samples'],start=1):
            row=next(r for r in record['rows'] if r['phase']=='deck-roundtrip')
            hosted_rows.append({'tier':tier,'arm':arm,'round':round_number}|{k:row[k] for k in ('elapsedMs','nativeCalls','propertyWrites','snapshots','moduleLoads')})
write_csv('native-cpu.csv',native)
write_csv('native-counters.csv',native_trace)
write_csv('native-deck-readiness.csv',native_decks)
write_csv('default-worker-deck.csv',worker)
write_csv('map-loop.csv',loops)
write_csv('hosted-same-source-deck.csv',hosted_rows)
(out/'summary.json').write_text(json.dumps({
    'nativeCPU':group(native,['arm','mode','phase'],phase_fields),
    'nativePairedCPU':pair(native,'prior','fixed',['mode','phase'],phase_fields),
    'nativeCounters':group(native_trace,['arm','phase'],trace_fields),
    'nativePairedCounters':pair(native_trace,'prior','fixed',['phase'],trace_fields),
    'nativeDeckReady':group(native_decks,['arm','mode','phase'],deck_fields),
    'map40':group(loops,['arm'],['cpuMs40Reopens']),
    'map40Paired':pair(loops,'prior','fixed',[],['cpuMs40Reopens']),
    'defaultWorker':group(worker,['arm'],['elapsedMs','nativeCalls','propertyWrites','snapshots','moduleLoads']),
    'hostedSameSource':group(hosted_rows,['tier','arm'],['elapsedMs','nativeCalls','propertyWrites']),
    'hostedSameSourcePaired':pair(hosted_rows,'baseline','candidate',['tier'],['elapsedMs','nativeCalls','propertyWrites']),
},indent=2)+'\n')
