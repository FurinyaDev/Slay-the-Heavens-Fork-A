#!/usr/bin/env python3
"""Turn the native-Harness raw TSV outputs into reusable tables and SVGs."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import html
import json
import math
from pathlib import Path
import statistics

parser = argparse.ArgumentParser()
parser.add_argument('raw',type=Path,nargs='+')
parser.add_argument('--out',type=Path,required=True)
args = parser.parse_args()
out = args.out
out.mkdir(parents=True,exist_ok=True)

phase_columns = ['phase','cpu_ms','wall_ms','updates','peak_update_ms']
trace_columns = ['seq','phase','event','wall_ms','cumulative_cpu_ms','lua_kib','rss_kib','rss_hwm_kib',
                 'controls_created','controls_destroyed','controls_tracked_alive','browser_roots_created',
                 'browser_parts_created','sdk_calls','property_writes','get_child_calls','set_visible_calls']
deck_columns = ['phase','roots_before','parts_before','new_roots','new_parts','callback_ms',
                'uncovered_round','first_complete_round','full_ready_round','first_complete_cpu_ms']
phases, traces, decks, stack_rows, method_rows = [], [], [], [], []
status_rows = []
for directory in args.raw:
    for record in map(json.loads,(directory/'runs.jsonl').read_text().splitlines()):
        common = {'series':directory.name,'arm':record['arm'],'mode':record['mode'],'round':record['round']}
        status_rows.append(common | record)
        if not record['complete']:
            continue
        run_points = {}
        for line in (directory/record['file']).read_text().splitlines():
            tag,*fields=line.split('\t')
            if tag=='PHASE':
                row=dict(zip(phase_columns,[fields[0],*map(float,fields[1:])],strict=True))
                phases.append(common | row)
            elif tag=='TRACE':
                point=[int(fields[0]),*fields[1:3],*map(float,fields[3:])]
                run_points[point[0]]=common | dict(zip(trace_columns,point,strict=True)) | {'update_cpu_ms':None}
            elif tag=='UPDATE':
                run_points[int(fields[0])]['update_cpu_ms']=float(fields[2])
            elif tag=='DECK':
                decks.append(common | dict(zip(deck_columns,[fields[0],*map(float,fields[1:])],strict=True)))
            elif tag=='STACK':
                stack_rows.append(common | {'phase':fields[0],'stack':fields[1],'samples':int(fields[2])})
            elif tag=='METHOD':
                method_rows.append(common | {'phase':fields[0],'method':fields[1],'cumulative_calls':int(fields[2])})
        traces.extend(run_points.values())


def write_csv(name, rows):
    if not rows:
        return
    with (out/name).open('w',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def describe(values):
    return {'n':len(values),'p50':round(statistics.median(values),4),'max':round(max(values),4),
            'min':round(min(values),4),'samples':[round(x,5) for x in values]}


def summary(rows, labels, metrics):
    groups=defaultdict(list)
    for row in rows:
        groups[tuple(row[label] for label in labels)].append(row)
    return [dict(zip(labels,key)) | {metric:describe([x[metric] for x in group]) for metric in metrics} for key,group in groups.items()]


phase_resources=[]
physical=('lua_kib','rss_kib','rss_hwm_kib','controls_created','controls_destroyed','controls_tracked_alive',
          'browser_roots_created','browser_parts_created','sdk_calls','property_writes','get_child_calls','set_visible_calls')
by_phase=defaultdict(list)
for row in traces:
    by_phase[tuple(row[key] for key in ['series','arm','round','phase'])].append(row)
for (series,arm,round_number,phase),points in by_phase.items():
    first,last=points[0],points[-1]
    endpoint={name+'_delta':last[name]-first[name] for name in physical}
    deltas=[current['lua_kib']-before['lua_kib'] for before,current in zip(points,points[1:])]
    metrics={'sampled_max_lua_kib':max(row['lua_kib'] for row in points),
             'sampled_max_rss_kib':max(row['rss_kib'] for row in points),
             'observed_negative_gc_intervals':sum(x<0 for x in deltas),
             'observed_net_reclaimed_kib':-sum(min(0,x) for x in deltas)}
    phase_resources.append(dict(series=series,arm=arm,round=round_number,phase=phase) | endpoint | metrics)

pairs=defaultdict(list)
for row in phases:
    pairs[(row['series'],row['arm'],row['round'],row['phase'])].append(row)
overhead=[]
for (series,arm,round_number,phase),values in pairs.items():
    by_mode={row['mode']:row['cpu_ms'] for row in values}
    if 'bare' not in by_mode:
        continue
    for mode in ('profile','trace'):
        if mode in by_mode:
            denominator=by_mode['bare']
            overhead.append(dict(series=series,arm=arm,round=round_number,phase=phase,mode=mode,
                                 cpu_ms_delta=by_mode[mode]-denominator,cpu_ratio=by_mode[mode]/denominator))

phase_labels=['series','arm','mode','phase']
phase_summary=summary(phases,phase_labels,phase_columns[1:])
deck_summary=summary(decks,phase_labels,deck_columns[1:])
resource_summary=summary(phase_resources,['series','arm','phase'],list(phase_resources[0])[4:]) if phase_resources else []
overhead_summary=summary(overhead,phase_labels,['cpu_ms_delta','cpu_ratio'])
write_csv('runtime-runs.csv',status_rows)
write_csv('runtime-phases.csv',phases)
write_csv('runtime-trace.csv',traces)
write_csv('runtime-deck.csv',decks)
write_csv('runtime-stacks.csv',stack_rows)
write_csv('runtime-sdk-methods.csv',method_rows)
write_csv('runtime-phase-resources.csv',phase_resources)
write_csv('runtime-instrumentation-overhead.csv',overhead)
(out/'runtime-summary.json').write_text(json.dumps({'phase':phase_summary,'deck':deck_summary,'resources':resource_summary,
                                                     'instrumentationOverhead':overhead_summary},indent=2)+'\n')


phase_names=[('Cold start','cold-module-load','cold-start'),('First fight','first-fight'),('Ten-card hand','ten-card-hand'),
             ('Three-card sequence','multi-play'),('First deck open','deck-first-open'),('Deck page switch + close','deck-page-switch')]


def panel(title,phase_ids,x,y,width):
    rows=[r for r in stack_rows if r['arm']=='hotfix' and r['phase'] in phase_ids]
    counter=Counter()
    for row in rows:
        frames=row['stack'].split(';')
        if len(phase_ids)>1:
            frames.insert(0, 'Lua fixture modules' if row['phase']=='cold-module-load' else 'Mock cloning + OnStart')
        counter[tuple(frames)] += row['samples']
    root={}
    for frames,amount in counter.items():
        tree=root
        for entry in frames:
            if entry not in tree:
                tree[entry]=[0,{}]
            tree[entry][0]+=amount
            tree=tree[entry][1]
    samples=sum(counter.values())
    svg=[f'<text x="{x}" y="{y}" class="subtitle">{html.escape(title)}</text>',
         f'<text x="{x+width}" y="{y}" class="caption" text-anchor="end">{samples:,} samples</text>']
    max_depth=10
    def draw(tree,left,bottom,bar_width,depth,total):
        if depth>=max_depth or total==0:
            return
        for label,(count,subtree) in sorted(tree.items(),key=lambda item:(-item[1][0],item[0])):
            size=bar_width*count/total
            if size<.28:
                left+=size
                continue
            h=18
            y_now=bottom-depth*h
            key=label.split(':',1)[0]
            hue=int(hashlib.sha1(key.encode()).hexdigest()[:5],16)%80+14
            if key.startswith(('game_ui_fixture','native_ui_contract')):
                hue=196
            title=f'{label} • {count} of {samples} sampled instructions ({count*100/samples:.1f}% of workload)'
            svg.append(f'<g><title>{html.escape(title)}</title><rect x="{left:.2f}" y="{y_now:.2f}" width="{size:.2f}" height="{h-1}" rx="2" fill="hsl({hue},64%,76%)" stroke="#192532" stroke-width=".25"/>')
            count_chars=int((size-7)//5.2)
            if count_chars>=7:
                short=label if len(label)<=count_chars else label[:count_chars-1]+'…'
                svg.append(f'<text x="{left+3:.2f}" y="{y_now+12.2:.2f}" class="frame">{html.escape(short)}</text>')
            svg.append('</g>')
            draw(subtree,left,bottom,size,depth+1,count)
            left+=size
    draw(root,x,y+197,width,0,samples)
    tops=Counter()
    for frames,n in counter.items():
        tops[frames[-1]]+=n
    text=', '.join(f'{k} ({n*100/samples:.0f}%)' for k,n in tops.most_common(2)) if samples else 'No Lua stacks recorded'
    svg.append(f'<text x="{x}" y="{y+232}" class="caption">{html.escape(text)}</text>')
    return '\n'.join(svg)


def draw_flame():
    panels=[]
    for i,(label,*phase_ids) in enumerate(phase_names):
        panels.append(panel(label,phase_ids,38+(i%2)*694,126+(i//2)*252,660))
    width,height=1430,925
    runs=len({row['round'] for row in stack_rows if row['arm']=='hotfix'})
    (out/'cpu-lua-call-tree.svg').write_text(f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-label="Six measured Lua call trees">
<style>text{{font-family:system-ui,sans-serif;fill:#162737}}.title{{font-size:28px;font-weight:700}}.subtitle{{font-size:19px;font-weight:650}}.caption{{font-size:12px}}.frame{{font-family:monospace;font-size:8.6px;pointer-events:none}}</style>
<rect width="{width}" height="{height}" rx="8" fill="#fcfaf7"/>
<text x="38" y="48" class="title">Lua call trees by workload</text>
<text x="38" y="73" class="caption">Hotfix f10eefa2 · {runs} fresh Host runs · native texlua 5.3 · seed 42 · one stack per 5,000 VM instructions</text>
<text x="38" y="92" class="caption">Width shows Lua instruction samples. SDK internals, interpreter C work, and client GPU are unobserved. Blue frames are mock controls.</text>
{''.join(panels)}
<text x="38" y="900" class="caption">Stacks are shown up to 10 levels. Full stacks and separate phase process-CPU timings are retained in CSV.</text>
</svg>''')


def draw_trace(arm):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import ScalarFormatter

    selected=defaultdict(list)
    for row in traces:
        if row['series']==args.raw[0].name and row['arm']==arm:
            selected[row['round']].append(row)
    if arm=='live':
        def reclaimed(points):
            return -sum(min(0,after['lua_kib']-before['lua_kib']) for before,after in zip(points,points[1:]))
        with_reclamation={key:points for key,points in selected.items() if reclaimed(points)>0}
        candidates=with_reclamation or selected
        wanted=statistics.median(reclaimed(points) for points in candidates.values())
        round_number,points=min(candidates.items(),key=lambda item:abs(reclaimed(item[1])-wanted))
        identity='Live eb64f4e6'
        selection='illustrative heap reclamation'
    else:
        wanted=statistics.median(points[-1]['cumulative_cpu_ms'] for points in selected.values())
        round_number,points=min(selected.items(),key=lambda item:abs(item[1][-1]['cumulative_cpu_ms']-wanted))
        identity='Hotfix f10eefa2'
        selection='median total CPU'
    t0=points[0]['wall_ms']
    times=[(p['wall_ms']-t0)/1000 for p in points]
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'})
    fig,axes=plt.subplots(5,1,sharex=True,figsize=(15.6,10.1),gridspec_kw={'hspace':.20})
    fig.patch.set_facecolor('#fcfaf7')
    fig.text(.08,.966,'Resource trace across startup, combat and deck browsing',fontsize=22,weight='bold',color='#182838')
    fig.text(.08,.932,f'{identity} · round {round_number} of {len(selected)} ({selection}) · texlua Host with instrumented SDK doubles · seed 42',color='#405265')
    phase_start={}
    phase_end={}
    for i,p in enumerate(points):
        if p['event']=='begin': phase_start[p['phase']]=i
        if p['event']=='end': phase_end[p['phase']]=i
    colors=['#4772a305','#4772a317']
    for j,(phase,start) in enumerate(phase_start.items()):
        end=phase_end[phase]
        for ax in axes:
            ax.axvspan(times[start],times[end],color=colors[j%2],zorder=0)
            ax.axvline(times[start],color='#a7b5bf',alpha=.45,lw=.7,zorder=0)
        if phase!='teardown':
            labels={'cold-module-load':'Lua modules','cold-start':'Host start','enter-map':'Enter map',
                    'first-fight':'First fight','ten-card-hand':'Ten cards','multi-play':'Three plays',
                    'idle-120':'Idle','deck-first-open':'Cold deck','deck-page-switch':'Next + close',
                    'deck-warm-open':'Warm deck','deck-close-loop':'Reopens'}
            value=(times[start]+times[end])/2
            height=.70 if phase in ('deck-first-open','deck-warm-open') else .97
            axes[0].text(value,height,labels[phase],transform=axes[0].get_xaxis_transform(),ha='left',va='top',
                         rotation=30,fontsize=8,backgroundcolor='#fcfaf7',color='#2c4053')
    for ax in axes:
        ax.set_facecolor('#fcfaf7')
        ax.spines[['right','top']].set_visible(False)
        ax.grid(axis='y',alpha=.18)
        ax.set_xlim(0,times[-1]*1.013)
    def plot(ax,key,label,color,scale=1):
        ax.plot(times,[row[key]/scale for row in points],label=label,color=color,lw=1.5)
    cp=[row['cumulative_cpu_ms'] for row in points]
    ratio=[100*(b-a)/(1000*(u-t)) if u-t>=.001 else math.nan for a,b,t,u in zip(cp,cp[1:],times,times[1:])]
    axes[0].plot(times[1:],ratio,label='Process CPU share (% of one core; intervals ≥1 ms)',color='#255ab3',linewidth=1)
    axes[0].set_ylabel('CPU share %')
    axes[0].set_ylim(0,max([x for x in ratio if math.isfinite(x)]+[100])*1.4)
    cpu_axis=axes[0].twinx()
    cpu_axis.plot(times,cp,color='#933e73',linewidth=1.5,alpha=.72,label='CPU elapsed')
    cpu_axis.set_ylabel('CPU elapsed (ms)',color='#8b3468')
    cpu_axis.spines['top'].set_visible(False)
    for key,label,color in [('rss_kib','Process RSS','#234a91'),('rss_hwm_kib','Process peak RSS','#6a80aa'),('lua_kib','Lua heap','#b25f33')]:
        plot(axes[1],key,label,color,1024)
    axes[1].set_ylabel('Memory (MiB)')
    for key,label,color in [('controls_tracked_alive','Tracked live controls','#245e56'),('controls_created','Created controls','#6c9b34'),('controls_destroyed','Destroyed controls','#a44756')]:
        plot(axes[2],key,label,color)
    axes[2].set_yscale('symlog',linthresh=100)
    axes[2].set_ylabel('Mock controls')
    for key,label,color in [('sdk_calls','Counted SDK methods','#234a91'),('property_writes','Direct mock property writes','#b25f33'),('get_child_calls','GetChild subset','#64894b')]:
        plot(axes[3],key,label,color)
    axes[3].set_ylabel('Cumulative operations')
    updates=[(t,p['update_cpu_ms']) for t,p in zip(times,points) if p['update_cpu_ms'] is not None]
    axes[4].scatter([p[0] for p in updates],[p[1] for p in updates],label='Offline OnUpdate CPU',color='#255cb0',s=11)
    axes[4].set_yscale('symlog',linthresh=1)
    axes[4].set_ylabel('Update time (ms)')
    axes[4].set_xlabel('Elapsed wall time inside the fresh process (seconds)')
    garbage=[(t,b['lua_kib']-a['lua_kib']) for a,b,t in zip(points,points[1:],times[1:]) if b['lua_kib']<a['lua_kib']]
    gc=axes[4].twinx()
    gc.scatter([g[0] for g in garbage],[-g[1]/1024 for g in garbage],label='Net Lua heap decreases',color='#a44756',marker='x',s=22)
    gc.set_ylabel('Net heap decrease (MiB)',color='#a44756')
    if not garbage:
        gc.set_ylim(0,1)
        gc.set_yticks([0])
        gc.text(.99,.93,'No sampled interval with net heap decrease',transform=gc.transAxes,ha='right',va='top',color='#a44756',fontsize=8)

    gc.spines['top'].set_visible(False)
    for index,ax in enumerate(axes):
        h,l=ax.get_legend_handles_labels()
        if index in (0,4):
            h2,l2=(cpu_axis if index==0 else gc).get_legend_handles_labels();h+=h2;l+=l2
        ax.legend(h,l,loc='best',frameon=False,ncol=min(len(l),3),fontsize=8)
    fig.text(.08,.032,'Heap decreases indicate net reclamation between samples. GC cycle and pause timing, production rendering, and SDK internals were unobserved.',fontsize=9,color='#405265')
    fig.subplots_adjust(left=.084,right=.916,bottom=.091,top=.908)
    fig.savefig(out/('resource-trace.svg' if arm=='hotfix' else 'resource-trace-live.svg'),facecolor=fig.get_facecolor(),metadata={'Date':None})
    plt.close(fig)

if stack_rows:
    draw_flame()
if traces:
    draw_trace('hotfix')
    draw_trace('live')
