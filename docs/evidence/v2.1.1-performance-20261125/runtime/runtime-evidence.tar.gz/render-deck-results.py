#!/usr/bin/env python3
from collections import defaultdict
import argparse
import csv
import json
from pathlib import Path
import statistics

parser=argparse.ArgumentParser()
parser.add_argument('raw',type=Path)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
args.out.mkdir(parents=True,exist_ok=True)
readable,resources=[],[]
for line in (args.raw/'runs.jsonl').read_text().splitlines():
    status=json.loads(line)
    if not status['complete']:
        continue
    for row in (args.raw/status['file']).read_text().splitlines():
        tag,*fields=row.split('\t')
        if tag=='FIELDS':
            timing_columns=fields
        if tag=='RESOURCE_FIELDS':
            resource_columns=fields
        record={'arm':status['arm'],'round':status['round'],'source_file':status['file']}
        if tag=='ROW':
            readable.append(record | dict(zip(timing_columns,fields,strict=True)))
        elif tag=='RESOURCE':
            resources.append(record | dict(zip(resource_columns,fields,strict=True)))


def emit(file,rows):
    with (args.out/file).open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


emit('deck-map-timing.csv',readable)
emit('deck-map-lifecycle.csv',resources)
groups=defaultdict(list)
keys=['arm','amount','synthetic_clock_seconds','phase']
metrics=['callback_ms','uncovered_frame','first_complete_frame','ready_frame','first_complete_cpu_ms','ready_cpu_ms',
         'peak_update_ms','veil_frames','hint_frames','live_panel_nodes','live_listeners','new_roots','new_parts']
for record in readable:
    groups[tuple(record[k] for k in keys)].append(record)
summary=[]
for values,group in groups.items():
    item=dict(zip(keys,values,strict=True)) | {'n':len(group)}
    for metric in metrics:
        values=[float(row[metric]) for row in group]
        item[metric]={'p50':statistics.median(values),'max':max(values),'samples':values}
    summary.append(item)
(args.out/'deck-map-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
