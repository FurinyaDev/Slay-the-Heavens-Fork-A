import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root=process.cwd();
const fromCheckout=file=>import(pathToFileURL(resolve(root,'scripts',file)));
const { prepareRefinedReleaseMonsterArt, refinedReleaseMonsterRegistry }=await fromCheckout('refined-release-monsters.mjs');
const { monsterActorTiers }=await fromCheckout('monster-art.mjs');
const { toLua }=await fromCheckout('build-lua-data.mjs');
const data=prepareRefinedReleaseMonsterArt(JSON.parse(readFileSync(refinedReleaseMonsterRegistry,'utf8')));
const { templateByDefinition }=monsterActorTiers(data);
const byIndex={4:'AbyssMonsterActor41',5:'AbyssMonsterActor96',6:'AbyssMonsterActor115'};
const byName=Object.fromEntries(Object.entries(byIndex).map(([index,name])=>[name,Number(index)]));
const byDefinition=Object.fromEntries(Object.entries(templateByDefinition).map(([definition,name])=>[definition,byName[name]]));
writeFileSync(`${process.argv[2]}/profile_monster_bindings.lua`,
  `return {indexToTemplate={${Object.entries(byIndex).map(([i,name])=>`[${i}]=${toLua(name)}`).join(',')}},definitionToIndex=${toLua(byDefinition)}}\n`);
