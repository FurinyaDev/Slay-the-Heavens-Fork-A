from pathlib import Path
import hashlib
import re
import shutil
import subprocess
import sys

roots = [Path(name) for name in sys.argv[1:]]
repo = Path(subprocess.check_output(['git', '-C', str(roots[0]), 'rev-parse', '--path-format=absolute', '--git-common-dir'],text=True).strip())
for root in roots:
    for listed in subprocess.check_output(['git','-C',str(root),'lfs','ls-files','--name-only']).splitlines():
        if not listed:
            continue
        path = root / listed.decode()
        if path.stat().st_size > 200:
            continue
        match = re.search(rb'oid sha256:([0-9a-f]{64})', path.read_bytes())
        if not match:
            continue
        digest = match[1].decode()
        src = repo / 'lfs' / 'objects' / digest[:2] / digest[2:4] / digest
        if src.is_file():
            assert hashlib.sha256(src.read_bytes()).hexdigest() == digest
            shutil.copyfile(src, path)
