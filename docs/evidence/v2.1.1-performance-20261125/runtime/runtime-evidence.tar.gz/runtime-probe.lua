-- Offline native Lua Host diagnostic. Reuses the official-deck probe's SDK doubles.
local here=assert(arg[0]:match('^(.*)/[^/]+$'))
local source=os.getenv('PROFILE_SOURCE') or 'src/lua'
local generated=os.getenv('PROFILE_GENERATED') or 'build/profile-ui'
local mode=os.getenv('PROFILE_MODE') or 'trace'
local profile=mode=='profile'
local trace=mode=='trace'
local amount=tonumber(os.getenv('PROFILE_DECK_AMOUNT')) or 75
package.path=generated..'/?.lua;'..source..'/?.lua;src/lua/?.lua;'..package.path
local clock=os.clock
local gettime=require('socket').gettime
local startWall=gettime()
local rawprint=print
local appLogs={}
print=function(...)
    local terms={...}
    for i,v in ipairs(terms)do terms[i]=tostring(v)end
    appLogs[#appLogs+1]=table.concat(terms,' ')
end
local counts={nativeCalls=0,propertyWrites=0,methods={},properties={}}
local created,destroyed,roots,parts=0,0,0,0
local phase,beginCPU,beginWall,phaseUpdates,phasePeak,phaseStart= nil,nil,nil,0,0,0
local elapsedCPU=0
local seq=0
local function rss()
    local f=assert(io.open('/proc/self/status'))
    local s=f:read('*a');f:close()
    return s:match('VmRSS:%s+(%d+)') or '',s:match('VmHWM:%s+(%d+)') or ''
end
local function emit(...)
    local row={...}
    for i,x in ipairs(row)do row[i]=tostring(x)end
    rawprint(table.concat(row,'\t'))
end
local function point(event,cpu)
    if not trace then return end
    local vm,peak=rss()
    emit('TRACE',seq,phase,event,(gettime()-startWall)*1000,elapsedCPU+cpu,collectgarbage('count'),vm,peak,
        created,destroyed,created-destroyed,roots,parts,counts.nativeCalls,counts.propertyWrites,counts.methods.GetChild or 0,counts.methods.SetVisible or 0)
    seq=seq+1
end
local stacks={}
local function sample()
    local chain={}
    for depth=2,50 do
        local d=debug.getinfo(depth,'Sn')
        if not d then break end
        if d.what~='C' and d.source:sub(1,1)=='@' then
            local name=d.source:match('([^/]+)$')
            if name~='runtime-probe.lua' then
                table.insert(chain,1,name..':'..d.linedefined..' '..(d.name or '<chunk>'))
            end
        end
    end
    if #chain==0 then return end
    local key=table.concat(chain,';')
    stacks[key]=(stacks[key] or 0)+1
end
local function enter(label)
    phase,phaseUpdates,phasePeak=label,0,0
    stacks={}
    point('begin',0)
    phaseStart=elapsedCPU
    if profile then debug.sethook(sample,'',5000) end
    beginWall=gettime()
    beginCPU=clock()
end
local function leave()
    local cpu=(clock()-beginCPU)*1000
    local wall=(gettime()-beginWall)*1000
    if profile then debug.sethook() end
    point('end',cpu)
    elapsedCPU=elapsedCPU+cpu
    emit('PHASE',phase,cpu,wall,phaseUpdates,phasePeak)
    if trace then
        for name,value in pairs(counts.methods) do emit('METHOD',phase,name,value) end
    end
    if profile then
        for stack,amount in pairs(stacks)do emit('STACK',phase,stack,amount)end
    end
end
local function update(dt)
    phaseUpdates=phaseUpdates+1
    local now=clock()
    OnUpdate(dt)
    local updateMs=(clock()-now)*1000
    phasePeak=math.max(phasePeak,updateMs)
    if trace then point('update', (clock()-beginCPU)*1000); emit('UPDATE',seq-1,phase,updateMs) end
end
local function read(path)
    local f=assert(io.open(path));local s=f:read('*a');f:close();return s
end
local function replaceOne(s,anchor,substitution)
    local first,last=s:find(anchor,1,true); assert(first,anchor)
    assert(not s:find(anchor,last+1,true),'ambiguous fixture anchor')
    return s:sub(1,first-1)..substitution..s:sub(last+1)
end
local F,Native,GameUI,Portraits,Binding
enter('cold-module-load')
local fixture='tests/lua/support/game_ui_fixture.lua'
if trace then
    local observer=os.getenv('PROFILE_OBSERVER') or 'scripts/runtime-baseline/observer.lua'
    local data=replaceOne(read(observer),"{'SetVisible'","{'GetChild','GetChildren','SetActive','SetVisible'")
    local observe=assert(load(data,'@'..observer))()
    ABYSS_PROFILE_CREATE=function(control)
        created=created+1
        observe(control,counts)
    end
    ABYSS_PROFILE_DESTROY=function()destroyed=destroyed+1 end
    local fixtureCode=replaceOne(read(fixture),'return NativeContract.control(self,spec)',
        'local control = NativeContract.control(self,spec); ABYSS_PROFILE_CREATE(control); return control')
    fixtureCode=replaceOne(fixtureCode,'engineAlive[control]=false',
        'if engineAlive[control]~=false then ABYSS_PROFILE_DESTROY() end; engineAlive[control]=false')
    F=assert(load(fixtureCode,'@'..fixture))()
else
    F=dofile(fixture)
end
Native=dofile('tests/lua/support/native_art_controls.lua')
GameUI=require('abyss_game_ui')
Portraits=require('abyss_traveler_portraits')
Binding=require('abyss_deck_browser_binding')
leave()

local frame=1/60
enter('cold-start')
local canvas=F.control({children=F.Layout})
local stage=canvas:GetChild('stage')
for _,name in ipairs({'nodePanel','choicePanel'})do
    local native=stage:GetChild(name)
    native.active=true
    function native:SetActive(active)
        self.active=active
        F.setEngineActive(self,active)
    end
end
local factory,actors=F.deckBrowser(),F.monsterActors()
local tiers=require('profile_monster_bindings')
local actorSerial=0
Binding.templateIndex=101
local deckParts={}
for i,part in ipairs(Binding.parts)do
    part.templateIndex=101+i
    deckParts[part.templateIndex]=part
end
package.loaded.abyss_monster_actor_binding={enabled=true,templateIndex=actors.templateIndex,
    containerTemplateIndex=actors.containerTemplateIndex,powerTemplateIndex=actors.powerTemplateIndex,
    templateIndexByDefinition=tiers.definitionToIndex}
local createHost=GameUI.new
local host
GameUI.new=function(root,data,presentation,event,platform)
    assert(platform.nativePageLifecycle and platform.deckBrowser)
    host=createHost(root,data,presentation,event,platform)
    root.ui=host
    return host
end
local function quiet()end
local createPortraits=Portraits.new
Portraits.new=function()
    return {tick=quiet,sync=quiet,syncResult=quiet,battlePose=quiet,release=quiet,onEngineDestroy=quiet,
        warmSelection=quiet,status=function()return {} end,readyForPage=function()return true end}
end
script={object=canvas,GetParam=function()return false end,EnableUpdate=function(self,v)self.updating=v end}
Enum={CursorEventType={CursorClick='click',CursorDown='down',CursorUp='up'},
    ImageSource={StaticReference='static'},Device={Mobile='mobile'},ImageType={Basic='basic',Stretch='stretch'}}
Color=setmetatable({FromRGBA=function(r,g,b,a)return {r=r,g=g,b=b,a=a}end},
    {__call=function(_,r,g,b,a)return {r=r,g=g,b=b,a=a}end})
game={GetUICanvasSize=function()return 1280,720 end,IsTestPlay=function()return true end,
    GetDevice=function()return 'desktop'end,GetCursorUIPos=function()return 0,0 end,
    InstantiateClientUIControl=function(index,parent)
        if index>=Binding.templateIndex then
            local part=deckParts[index]
            assert(index==Binding.templateIndex or part,'unknown browser template ID')
            if part then parts=parts+1 else roots=roots+1 end
            return factory.create(parent,part)
        end
        local name=tiers.indexToTemplate[index]
        if not name then return actors.instantiate(index,parent) end
        local control=F.control(assert(F.Templates[name]),parent)
        actorSerial=actorSerial+1
        parent.children['profileActor'..actorSerial]=control
        Native.decorate(assert(control:GetChild('monsterArt')))
        return control
    end,
    DestroyClientUIControl=function(control)
        if control.name=='AbyssBattlePileCard' then return factory.destroy(control)end
        return actors.destroy(control)
    end}
local installed=loadfile(source..'/abyss_ui.lua') or assert(loadfile('src/lua/abyss_ui.lua'))
installed()
OnStart()
GameUI.new,Portraits.new=createHost,createPortraits
assert(host and script.updating and host.pageReveal:usesFade(),table.concat(appLogs,'\n'))
host.seed=42
local function settle()
    for _=1,180 do
        if not host.pageReveal:covered() and not host.starting and not host.battleUI.busy then
            assert(script.updating and not host.disabled,table.concat(appLogs,'\n'))
            return
        end
        update(frame)
    end
    error(host.pageReveal.error or table.concat(appLogs,'\n'))
end
settle()
assert(host.mode=='menu' and not host.pageReveal:covered())
leave()

enter('enter-map')
assert(host:start());settle()
assert(host:selectCharacter('traveler'));settle()
assert(host:confirmCharacter());settle()
if host.mode=='node' then
    for _,option in ipairs({1,2,1})do
        assert(F.click(stage,'nodePanel','eventView/option'..option));settle()
    end
end
assert(host.mode=='map' and host.mapUI.navigationEnabled)
local original={}
for i,v in ipairs(host.run.deck)do original[i]=v end
for i=1,amount do
    local card=F.Combat.copy(original[(i-1)%#original+1]);card.uid=1000+i
    host.run.deck[i]=card
end
host:refresh();settle()
assert(host.run.runSeed=='42',tostring(host.run.runSeed))
leave()

enter('first-fight')
local first=assert(F.Nodes.available(host.run,host.map)[1])
assert(host.mapUI:choose(first.id));settle()
assert(host.run.phase=='combat',tostring(host.run.phase))
local battle=host.run.combat
assert(#battle.hand==5)
leave()

enter('ten-card-hand')
F.Combat.draw(battle,10-#battle.hand)
assert(#battle.hand==10)
host.battleUI:render()
for _=1,60 do update(frame)end
leave()

enter('multi-play')
local enemy=battle.enemies[1]
enemy.hp=math.max(enemy.hp,300);enemy.maxHp=math.max(enemy.maxHp,enemy.hp)
battle.energy=math.max(battle.energy,10)
for _=1,3 do
    local slot
    for i,instance in ipairs(battle.hand)do
        if F.Combat.canPlay(battle,instance.uid,1)then slot=i;break end
    end
    assert(slot,'no playable card')
    local instance=battle.hand[slot]
    host.battleUI:playSlot(slot)
    assert(host.battleUI.selected==instance.uid)
    local noTarget=F.Combat.canPlay(battle,instance.uid,nil)
    host.battleUI:playSelected(not noTarget and 1 or nil)
    settle()
end
assert(#battle.hand==7)
leave()

enter('idle-120')
for _=1,120 do update(frame)end
leave()

local panel=stage:GetChild('deckPanel')
local grid,chrome=panel:GetChild('pileGrid'),panel:GetChild('pileChrome')
local open=stage:GetChild('deckEntry'):GetChild('open'):GetChild('hit')
local back=panel:GetChild('pileReturn'):GetChild('hit')
local veil=stage:GetChild('pageReveal'):GetChild('veil')
local function visible(control)
    while control do
        if control.alive==false or control.visible==false then return false end
        control=control.parent
    end
    return true
end
local function deckVisual()
    local blocked=visible(veil) and (not veil.imageColor or veil.imageColor.a>0)
    local n=0
    if not blocked and visible(grid) then
        for _,control in pairs(grid.children)do
            if control.name=='AbyssBattlePileCard' and visible(control) then
                assert(control:GetChild('face'):GetChild('name').text~='','visible card not painted')
                n=n+1
            end
        end
    end
    return visible(chrome),not blocked and visible(panel),n
end
local function deckOpen(label)
    local beforeRoots,beforeParts=roots,parts
    enter(label)
    assert(visible(open) and open.click())
    local callback=(clock()-beginCPU)*1000
    local firstFrame,fullFrame,uncoveredFrame,firstCpu
    for i=0,180 do
        local _,uncovered,n=deckVisual()
        if uncovered then uncoveredFrame=uncoveredFrame or i end
        if n>0 and not firstFrame then firstFrame,firstCpu=i,(clock()-beginCPU)*1000 end
        if not host.deckUI.pendingGrid and not host.pageReveal:covered() then
            fullFrame=i;assert(n==math.min(amount,10),tostring(n));break
        end
        update(frame)
    end
    assert(firstFrame and fullFrame and uncoveredFrame,'deck readiness not reached')
    leave()
    emit('DECK',label,beforeRoots,beforeParts,roots-beforeRoots,parts-beforeParts,callback,uncoveredFrame,firstFrame,fullFrame,firstCpu)
end
assert(roots==0,'prewarmed before cold deck scenario')
deckOpen('deck-first-open')
enter('deck-page-switch')
if amount>10 then assert(host.deckUI:stepPage(1));settle();assert(host.deckUI.pageIndex==2)end
assert(back.click());settle();assert(not visible(panel))
leave()
deckOpen('deck-warm-open')
enter('deck-close-loop')
assert(back.click());settle()
local openRoots=roots
for _=1,3 do assert(open.click());settle();assert(back.click());settle()end
assert(roots==openRoots,'reopen grew deck roots')
leave()

enter('teardown')
OnDestroy();assert(not script.updating)
leave()
emit('COMPLETE',mode,amount,first.id,#battle.enemies,#battle.hand,roots,parts)
