#!/usr/bin/env python3
import argparse
from pathlib import Path
import json
import os
import subprocess

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--out',type=Path,default=root/'raw'/'deck-map')
args=parser.parse_args()
out=args.out.resolve()
out.mkdir(parents=True,exist_ok=True)
with (out/'runs.jsonl').open('x') as manifest:
    for block in range(4):
        for amount,step,cycles in [(10,0,0),(75,0,20 if block==0 else 0),(75,.0021,0)]:
            for arm in (('hotfix','progressive') if block%2==0 else ('progressive','hotfix')):
                work=root/('hotfix' if arm=='hotfix' else 'deck-experiment')
                file=f'{block+1:02}-{amount}-{step}-{arm}.txt'
                settings=dict(os.environ,DECK_GENERATED='build/profile-ui',DECK_AMOUNT=str(amount),DECK_SAMPLES='1',
                              DECK_SYNTHETIC_CLOCK=str(step),DECK_CYCLES=str(cycles))
                with (out/file).open('x') as stream:
                    try:
                        run=subprocess.run(['texlua',str(root/'deck-map-probe.lua')],cwd=work,env=settings,
                                           stdout=stream,stderr=subprocess.STDOUT,timeout=60,check=False)
                        status=run.returncode
                    except subprocess.TimeoutExpired:
                        status='TIMEOUT'
                text=(out/file).read_text()
                receipt=dict(round=block+1,amount=amount,step=step,cycles=cycles,arm=arm,file=file,status=status,
                             complete=status==0 and text.count('\nROW\t')==2 and '\nRESOURCE\t' in text)
                manifest.write(json.dumps(receipt)+'\n')
                manifest.flush()
                print(json.dumps(receipt),flush=True)
