# Reproduce the v2.1.1 native Lua profile

The archived inputs are from `FurinyaWorks/Slay-the-Heavens` on Linux x86_64 (AMD EPYC 9V74). The outer cgroup uses four cores worth of CPU quota and 16 GiB memory, shared with other build and test jobs. The runners used LuaTeX 1.18.0 (Lua 5.3), Node 24.22.3, and Python 3.12.14. SVG resource plots additionally require matplotlib 3.10.8. The subprocess manifests capture all formal attempts, including nonzero exits and timeouts when present. Earlier fixture bring-up failures are retained in `raw/bringup-*.txt`.

## Prepare the source

Run from the extracted directory containing this document. `REPO` is an existing clone with the required objects. GitHub commit objects for the Hotfix must be available in that clone. The production compare does not use either old RC branch.

```sh
GIT_LFS_SKIP_SMUDGE=1 git -C "$REPO" worktree add --detach "$PWD/live" eb64f4e6cd45198118e123b6640dc491f186e329
GIT_LFS_SKIP_SMUDGE=1 git -C "$REPO" worktree add --detach "$PWD/hotfix" f10eefa27c75788cf0b753d5e9121e3887114218
GIT_LFS_SKIP_SMUDGE=1 git -C "$REPO" worktree add --detach "$PWD/deck-experiment" f10eefa27c75788cf0b753d5e9121e3887114218
git -C deck-experiment apply "$PWD/deck932-port-experiment.patch"
```

Use normal Git LFS checkout for the Git worktrees. On the measurement host the worktrees contained LFS pointers and Git LFS did not have checkout filters registered. The following downloaded and verified the required source objects without altering the repository's Git configuration.

```sh
git -C live lfs fetch -I 'art/characters/traveler-geo/portraits/**,art/lowpoly-select/**' -X '' origin eb64f4e6cd45198118e123b6640dc491f186e329
python hydrate.py "$PWD/live" "$PWD/hotfix" "$PWD/deck-experiment"
```

Build each worktree independently. The experiment's patch includes changed generated template inputs. The artifact manifest in `evidence/build-inputs.json` identifies the matching generated control trees and indexed data variants.

```sh
for tree in live hotfix deck-experiment; do
  (
    cd "$tree" || exit
    npm ci --ignore-scripts --cache "$PWD/../npm-scratch"
    mkdir -p build/profile-ui
    node scripts/build-lua-data.mjs data build/profile-ui/abyss_data.lua
    node scripts/build-ui.mjs build/profile-ui --official-assets --native-page-lifecycle --refined-release-monsters
    node ../bind-fixtures.mjs build/profile-ui
  ) || exit
 done
```

`bind-fixtures.mjs` reuses the build's actual map from monster definitions to tier templates. It supplies local nonproduction IDs for fixture template lookup. The experimental early battle cache arm overlays only `abyss_battle_card_view.lua` at `85f5c50b9b610f639e4d582507033206013bfc18`. It retains the hotfix's enemy-name optimization and the normal code from the selected worktree for every other module.

## Run and render

```sh
python run-runtime-profile.py --out rerun/baseline --rounds 5 \
  --observer hotfix/scripts/runtime-baseline/observer.lua \
  --arm live:live --arm hotfix:hotfix

python run-runtime-profile.py --out rerun/crossover --rounds 6 --modes bare \
  --observer hotfix/scripts/runtime-baseline/observer.lua \
  --arm hotfix:hotfix --arm full-battle:hotfix:battle-cache-overlay \
  --arm progressive:deck-experiment --arm both:deck-experiment:battle-cache-overlay

python run-deck-map.py --out rerun/deck-map
MPLCONFIGDIR="$PWD/mpl-cache" python render-runtime-profile.py rerun/baseline rerun/crossover --out rerun/tables
python render-deck-results.py rerun/deck-map --out rerun/tables
(cd deck-experiment && node --test --test-concurrency=1 tests/deck-pages.test.mjs)
```

The main workload uses seed 42, fixed 1280×720 resolution, synthetic 1/60 s update steps and the same stock Lua/browser fixture in both source arms. It exercises the first available map battle and then draws ten cards in the normal combat state. The three play commands use a fixture HP/energy floor to avoid ending the test early. The target enemy, actual hand and state transitions are retained by the existing rule methods. The selected 75-card fixture creates the same ten visible card cells in each arm. The map runner uses the #932 probe with a no-op portrait warmup hook and a larger readiness drain limit for the hotfix's room transition. The normal run uses the production `os.clock` budget and the deterministic arm advances the budget clock by 2.1 ms per check. All CPU measurements use real process CPU time.

The `bare` run omits Lua stack and SDK instrumentation. In `trace`, the existing observer wraps the supported methods and direct properties, with explicit `GetChild`, `GetChildren`, and `SetActive` extensions. Its method counters also include some probe reads, and nested fixture methods can be counted. Lifecycle counts cover mock objects allocated or explicitly destroyed through fixture hooks. `profile` keeps the raw debug hook stacks, which reflect Lua VM instruction frequency. `collectgarbage('count')` samples live Lua heap usage and an interval's drop is the lower bound on net bytes released during that interval. Native engine memory, native LuaHost, GPU, operating-system memory pressure on mobile, and official platform loading are outside the fixture.
